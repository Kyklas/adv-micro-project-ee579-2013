#include <stdio.h>
#include "iom16c62p.h"
#include <intrinsics.h>

#define CHECK_BIT(var,pos) ((var) & (1<<(pos)))



// Timer Interupt Test

int numVal = 15;

#pragma vector = INT0                 //specify interrupt to be called
__interrupt void sw_int0 (void)
  {                                  //increment LEDno by one,
   //ledNum = 1;
    //bitShift = bitShift << 1;
//    INT0IC &=0xF8;                   //Turn off interupt for INT0
    
   // numVal = 0; // on
    
    numVal = numVal << 1;
    
    for(int i=0;i<30000;i++){
      ;;;
    }
  }

#pragma vector = INT1
__interrupt void sw_int1 (void)
  {                                  //increment LEDno by one,
   //ledNum = 1;
    //bitShift = bitShift << 1;
//    INT0IC &=0xF8;                   //Turn off interupt for INT0
    
//    numVal = 15; // off
  
    numVal = numVal << 2;
    
    for(int i=0;i<30000;i++){
      ;;;
    }
  }





void timerSetup(){
  
  // interrupts
    INT0IC = 0xFF; // set interupt levels
      INT1IC = 0xFF; // set interupt levels
//      TA0IC = 0xFF; // timer interupt
  __enable_interrupt();
  
  // timer
    TA0MR = 0x00;  // was originaly 0x00
  TA0 = 6000; // 6000 cycles @ 6 Mhz = 1ms
  
  TABSR |= 0x01; // start the timer
  
    PD4 = 0xFF;
  P4 = 0x00; // on 
  

}


int main(void){
 timerSetup();


 
   int counter = 0;
   // timer test:
   while(1){
     
   
    if(TA0IC & (1 << 3)){
       TA0IC &= ~(1 << 3); // clear bit
       counter++;
       if(counter == 1000){ // one second
         if(numVal >= 15){
           
          numVal = numVal >> 1;  
          counter = 0;
         }
       }
       
    }
    
    if(numVal == 15){
      // do nothing
    }
    else if (numVal < 15){
      numVal = 15;
    }
    else if(numVal > 240){
       numVal = 240;  
    }

    P4 = numVal;
   }
}



 /* The first part of this section is a delay of a time determined by the value in  time 
      BTST 3, TA0IC // bit 3 of TA0IC will be set when the timer reaches 1 millisecond, so check it
      JZ mainloop // if it is still 0 (not set) go back to mainloop
      BCLR 3, TA0IC // however, if it is set, clear it 
      ADD.W #1, msec // a millisecond has passed, so count it in msec
      CMP.W time, msec // have we reached a second yet (compare the number of milliseconds counted in msec, with the total number we are supposed to wait)
      JNE mainloop // if not, wait another millisecond
 -----------------------------------------*/


  