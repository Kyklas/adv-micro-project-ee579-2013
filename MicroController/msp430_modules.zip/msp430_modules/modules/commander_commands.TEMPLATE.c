
#include <stdio.h>
#include "commander_commands.h"

//==================================================================================================
// Device-specific output functions
//==================================================================================================

#include <stdio.h>

void cmd_puts(char *str){
	printf(str); // Example using stdio.h
}

void cmd_putc(char chr){
	putchar(chr); // Example using stdio.h
}

// Code that disables incoming characters from being processed by commander. This function is
// automatically called before entering a user command.
void cmd_disable_input_processing(void){
	
}

// Code that re-enables incoming character processing. This function is called after a user command
// exits.
void cmd_enable_input_processing(void){
	
}

//==================================================================================================
// Custom Commands
//==================================================================================================

CMDRES_t cmdHello(uint8_t argc, char *argv[], uint8_t reset){
	cmd_puts("Hello World\r\n");
	return(CMD_EXIT);
}

//--------------------------------------------------------------------------------------------------
CMDRES_t cmdArgList(uint8_t argc, char *argv[], uint8_t reset){
	cmd_puts("Argument List:\r\n");
	int i;
	for(i=0;i<argc;i++){
		cmd_puts(argv[i]);
	}
	return(CMD_EXIT);
}

