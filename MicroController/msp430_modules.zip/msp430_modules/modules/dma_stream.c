/*
* Copyright (c) 2012, Alexander I. Mykyta
* All rights reserved.
* 
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met: 
* 
* 1. Redistributions of source code must retain the above copyright notice, this
*    list of conditions and the following disclaimer. 
* 2. Redistributions in binary form must reproduce the above copyright notice,
*    this list of conditions and the following disclaimer in the documentation
*    and/or other materials provided with the distribution. 
* 
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
* ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

/*==================================================================================================
* File History:
* NAME          DATE         COMMENTS
* Alex M.       09/07/2011   born
* 
*=================================================================================================*/

/**
* \addtogroup MOD_DMA_STREAM
* \{
**/
 
/**
* \file
* \brief Code for \ref MOD_DMA_STREAM "DMA Stream"
* \author Alex Mykyta (amykyta3@gmail.com)
**/

#include <stdint.h>
#include <stddef.h>
#include <msp430_xc.h>
#include "dma_isr.h"
#include "dma_internal.h"

///\cond PRIVATE

//==================================================================================================
// Internal Variables
//==================================================================================================
void *dma_stream_ptr[DMA_CHANNELS];

//==================================================================================================
// Internal Functions
//==================================================================================================
void instreamISR(uint8_t channel){
	((DMA_INSTREAM_t *)dma_stream_ptr)[channel]->laplead++;
}

//--------------------------------------------------------------------------------------------------
void outstreamISR(uint8_t channel){
	((DMA_OUTSTREAM_t *)dma_stream_ptr)[channel]->laplead--;
}

///\endcond

//==================================================================================================
// User Functions
//==================================================================================================
///\addtogroup DMASTREAM_FUNCTIONS
///\{
	
/**
* \brief Initializes an input stream to be handled by a DMA channel
* \param [in] dma_instream	Pointer to a DMA_INSTREAM_t object
* \param [in] bufptr		Pointer to a storage buffer
* \param [in] bufsize		Size of the buffer in bytes
* \param [in] dma_channel	DMA channel number to use
* \param [in] trigger		DMA trigger number (0-31) (See device-specific documentation)
* \param [in] srcAddr		Address to data source
* \param [in] wordsize		Byte (=1) or Word (=2) transfer
* \return Nothing
**/
void dma_instream_init(DMA_INSTREAM_t *dma_instream, void *bufptr, size_t bufsize,
						uint8_t dma_channel, uint8_t trigger, void *srcAddr, uint8_t wordsize){
	
	DMA_CHANNEL_t *DMA;
	uint8_t *DMACTL;
	
	// Setup DMA channel pointers
	switch(dma_channel){
		case 0:
			DMA = &DMA0CTL;
			DMACTL = &DMACTL0_L;
			break;
		case 1:
			DMA = &DMA1CTL;
			DMACTL = &DMACTL0_H;
			break;
		case 2:
			DMA = &DMA2CTL;
			DMACTL = &DMACTL1_L;
			break;
		default:
			return;
	}
	
	// stop DMA channel
	DMA->CTL = 0;
	
	// init dma_instream object
	dma_instream->bufptr = bufptr;
	dma_instream->bufsize = bufsize;
	dma_instream->laplead = 0;
	dma_instream->rdidx = 0;
	dma_instream->DMA = DMA;
	
	// register stream object
	dma_stream_ptr[dma_channel] = dma_instream;
	
	// attach ISR
	dma_AttachISR(dma_channel,instreamISR);
	
	// start DMA
	*DMACTL = trigger;
	DMA->SA = (uint32_t)srcAddr;
	DMA->DA = (uint32_t)bufptr;
	DMA->SZ = bufsize;
	if(wordsize == 1){
		DMA->CTL = DMADT_4 + DMADSTINCR_3 + DMASRCINCR_0 + DMADSTBYTE + DMASRCBYTE + DMAEN + DMAIE;
	}else{
		DMA->CTL = DMADT_4 + DMADSTINCR_3 + DMASRCINCR_0 + DMAEN + DMAIE;
	}
	
}

//--------------------------------------------------------------------------------------------------
/**
* \brief Read data from the DMA input stream buffer
* \param [in] dma_instream	Pointer to a DMA_INSTREAM_t object
* \param [in] dst		Destination of the data to be read. A \c NULL pointer discards the data.
* \param [in] size		Number of bytes to be read
* \retval RES_OVERRUN	Overrun error occurred. Data was overwritten in the storage buffer before it
* 						could be read
* \retval RES_PARAMERR	number of bytes available is less than the requested read size
* \retval RES_OK		
**/
RES_t dma_instream_read(DMA_INSTREAM_t *dma_instream, void *dst, size_t size){
	register size_t rdcount, rdidx;
	RES_t error;
	register uint8_t declap;
	
	rdcount = dma_instream_rdcount(dma_instream,&error);
	if(error = RES_OVERRUN){
		return(RES_OVERRUN);
	}else if(size > rdcount){
		return(RES_PARAMERR);
	}
	
	// No overrun. Perform read
	rdidx = dma_instream->rdidx;
	declap = 0;
	
	if((rdcount = dma_instream->bufsize - rdidx) <= size){
		// read operation will wrap around in stream buffer
		// read first half of stream buffer
		if(dst != NULL){
			memcpy(dst,dma_instream->bufptr+rdidx,rdcount);
		}
		//wrap around and continue
		rdidx = 0;
		declap++;
		size -= rdcount;
		dst = (uint8_t*)dst + rdcount;
	}
	
	if(size > 0){
		if(dst != NULL){
			memcpy(dst,dma_instream->bufptr+rdidx,size);
		}
		rdidx += size;
	}
	
	if(dst != NULL){
		// check if overrun occurred during read operation
		if(dmaTestOverrun(dma_instream) == RES_OVERRUN){
			return(RES_OVERRUN);
		}
	}
	
	// commit changes to object
	dma_instream->rdidx = rdidx;
	dma_instream->laplead -= declap;
	
	return(RES_OK);
	
}

//--------------------------------------------------------------------------------------------------
/**
* \brief Read data from the DMA input stream buffer without advancing the read pointer
* \param [in] dma_instream	Pointer to a DMA_INSTREAM_t object
* \param [in] dst		Destination of the data to be read.
* \param [in] size		Number of bytes to be read
* \retval RES_OVERRUN	Overrun error occurred. Data was overwritten in the storage buffer before it
* 						could be read
* \retval RES_PARAMERR	number of bytes available is less than the requested read size
* \retval RES_OK		
**/
RES_t dma_instream_peek(DMA_INSTREAM_t *dma_instream, void *dst, size_t size){
	register size_t rdcount, rdidx;
	RES_t error;
	
	if(dst == NULL) return(RES_OK);
	
	rdcount = dma_instream_rdcount(dma_instream,&error);
	if(error = RES_OVERRUN){
		return(RES_OVERRUN);
	}else if(size > rdcount){
		return(RES_PARAMERR);
	}
	
	// No overrun. Perform read
	rdidx = dma_instream->rdidx;
	
	if((rdcount = dma_instream->bufsize - rdidx) <= size){
		// read operation will wrap around in stream buffer
		// read first half of stream buffer
		memcpy(dst,dma_instream->bufptr+rdidx,rdcount);
		//wrap around and continue
		rdidx = 0;
		size -= rdcount;
		dst = (uint8_t*)dst + rdcount;
	}
	
	if(size > 0){
		memcpy(dst,dma_instream->bufptr+rdidx,size);
		rdidx += size;
	}
	
	// check if overrun occurred during read operation
	if(dmaTestOverrun(dma_instream) == RES_OVERRUN){
		return(RES_OVERRUN);
	}
	
	return(RES_OK);
}

//--------------------------------------------------------------------------------------------------
/**
* \brief Get the number of bytes available in the stream buffer
* \param [in] dma_instream	Pointer to a DMA_INSTREAM_t object
* \param [out] error	Returns RES_OVERRUN if DMA overwrote unread data in the buffer. Otherwise returns RES_OK.
* \return Number of bytes		
**/
size_t dma_instream_rdcount(DMA_INSTREAM_t *dma_instream, RES_t *error){
	register uint16_t wridx;
	register int8_t laplead;
	
	// get snapshot of DMA status
	do{
		laplead = dma_instream->laplead; //read lap
		wridx = dma_instream->DMA->SZ; //read size
	}while(dma_instream->laplead != laplead); //if laplead changed, may be invalid. try again
	
	wridx = dma_instream->bufsize - wridx; // calculate actual wridx
	
	switch(laplead){
		case 0:
			// Definitely no overrun
			*error = RES_OK;
			return(wridx - dma_instream->rdidx);
		case 1:
			//Possibly overrun. Compare pointers
			if(wridx > dma_instream->rdidx){
				// overrun happened
				// repair stream
				dma_instream->laplead = 0;
				dma_instream->rdidx = wridx;
				*error = RES_OVERRUN;
				return(0);
			}
			*error = RES_OK;
			return(wridx + dma_instream->bufsize - dma_instream->rdidx);
		default:
			// Definitely overrun
			// repair stream
			dma_instream->laplead = 0;
			dma_instream->rdidx = wridx;
			*error = RES_OVERRUN;
			return(0);
	}
}

//--------------------------------------------------------------------------------------------------

///\}
///\}
