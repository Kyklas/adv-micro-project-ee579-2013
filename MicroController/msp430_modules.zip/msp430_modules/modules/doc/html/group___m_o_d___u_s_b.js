var group___m_o_d___u_s_b =
[
    [ "Functions", "group___u_s_b___f_u_n_c_t_i_o_n_s.html", "group___u_s_b___f_u_n_c_t_i_o_n_s" ],
    [ "Definitions", "group___u_s_b___d_e_f_i_n_i_t_i_o_n_s.html", "group___u_s_b___d_e_f_i_n_i_t_i_o_n_s" ],
    [ "Events", "group___u_s_b___events.html", "group___u_s_b___events" ],
    [ "usb_api.c", "usb__api_8c.html", null ],
    [ "usb_api.h", "usb__api_8h.html", null ]
];