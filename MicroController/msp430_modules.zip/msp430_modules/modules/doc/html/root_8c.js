var root_8c =
[
    [ "root_PopEventData", "root_8c.html#gafc1d54235e5fbcbec826419b44769808", null ],
    [ "root_PushEvent", "root_8c.html#ga7543aa03d6d2c87bf009be3de873cf1e", null ],
    [ "root_ResetReasonString", "root_8c.html#ga808414caeacd1c29cc29888e51d0db7d", null ],
    [ "root_StartRootProcess", "root_8c.html#ga3250142bdd7576ff35fe337645c8a75a", null ],
    [ "root_YieldEvent", "root_8c.html#gac3a188d53345bbfa53c0a89d3e1292c6", null ]
];