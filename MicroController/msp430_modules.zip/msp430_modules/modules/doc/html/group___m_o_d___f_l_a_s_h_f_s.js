var group___m_o_d___f_l_a_s_h_f_s =
[
    [ "FFS_FILE_t", "struct_f_f_s___f_i_l_e__t.html", null ],
    [ "Functions", "group___f_f_s___f_u_n_c_t_i_o_n_s.html", "group___f_f_s___f_u_n_c_t_i_o_n_s" ],
    [ "Configuration Defines", "group___d_e_f___f_l_a_s_h_f_s___c_o_n_f_i_g.html", "group___d_e_f___f_l_a_s_h_f_s___c_o_n_f_i_g" ],
    [ "flash_fs.c", "flash__fs_8c.html", null ],
    [ "flash_fs.h", "flash__fs_8h.html", null ],
    [ "flash_fs_config.TEMPLATE.h", "flash__fs__config_8_t_e_m_p_l_a_t_e_8h.html", null ],
    [ "FFS_FILEMODE", "group___m_o_d___f_l_a_s_h_f_s.html#ga29a445c015670625f96f4edfcedf196b", [
      [ "FFS_CLOSED", "group___m_o_d___f_l_a_s_h_f_s.html#gga29a445c015670625f96f4edfcedf196ba287bd86cea90748d8f71687033de505f", null ],
      [ "FFS_RD", "group___m_o_d___f_l_a_s_h_f_s.html#gga29a445c015670625f96f4edfcedf196ba37ccad4929eb69f0481bce44a1219226", null ],
      [ "FFS_WR_APPEND", "group___m_o_d___f_l_a_s_h_f_s.html#gga29a445c015670625f96f4edfcedf196ba7a22cdafc0a89fb37bc25681850698fc", null ],
      [ "FFS_WR_REPLACE", "group___m_o_d___f_l_a_s_h_f_s.html#gga29a445c015670625f96f4edfcedf196ba3debb8708ec5991e856b341d7f39b7e8", null ]
    ] ]
];