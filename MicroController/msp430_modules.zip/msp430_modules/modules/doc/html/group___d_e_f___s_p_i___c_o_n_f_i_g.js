var group___d_e_f___s_p_i___c_o_n_f_i_g =
[
    [ "DUMMY_CHAR", "group___d_e_f___s_p_i___c_o_n_f_i_g.html#gaf113ef8698527437ed3ec7f3b1a7ab9f", null ],
    [ "SPI_CLK_DIV", "group___d_e_f___s_p_i___c_o_n_f_i_g.html#gabcbafe416e11c008a72313171af8c070", null ],
    [ "SPI_CLK_SRC", "group___d_e_f___s_p_i___c_o_n_f_i_g.html#ga615dfec6136b3ff96bf9fe605de2f77d", null ],
    [ "SPI_USE_USCI", "group___d_e_f___s_p_i___c_o_n_f_i_g.html#ga569fa7141587d23d0bca570ce38565de", null ]
];