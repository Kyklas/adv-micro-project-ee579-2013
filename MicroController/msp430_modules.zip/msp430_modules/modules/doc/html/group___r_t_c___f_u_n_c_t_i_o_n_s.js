var group___r_t_c___f_u_n_c_t_i_o_n_s =
[
    [ "rtcAlarm2Time", "group___r_t_c___f_u_n_c_t_i_o_n_s.html#ga30c2eb76ed0ad9fceca4b8b95ea9e823", null ],
    [ "rtcDeleteAlarm", "group___r_t_c___f_u_n_c_t_i_o_n_s.html#gad2a188e4efb5b7e8c9a300deca78960a", null ],
    [ "rtcDisableAlarm", "group___r_t_c___f_u_n_c_t_i_o_n_s.html#ga724ce31c0006288f909a7ba3ed050e98", null ],
    [ "rtcEnableAlarm", "group___r_t_c___f_u_n_c_t_i_o_n_s.html#gacf41f55bdbf8a30a94df79b002e3453f", null ],
    [ "rtcGetAlarm", "group___r_t_c___f_u_n_c_t_i_o_n_s.html#ga794540b092a02452e054f8a64831ee0f", null ],
    [ "rtcGetTime", "group___r_t_c___f_u_n_c_t_i_o_n_s.html#ga8364483f472db9b25db30843a548fd39", null ],
    [ "rtcInit", "group___r_t_c___f_u_n_c_t_i_o_n_s.html#ga5f6cddc7c2e2cbff9fcc8edc2ac6b841", null ],
    [ "rtcSetAlarm", "group___r_t_c___f_u_n_c_t_i_o_n_s.html#gab5d7a1addff3b96181347494c70df85e", null ],
    [ "rtcSetTime", "group___r_t_c___f_u_n_c_t_i_o_n_s.html#gaea2b56ed9ed219ba0a1ef63cbac29506", null ],
    [ "rtcTimeCmp", "group___r_t_c___f_u_n_c_t_i_o_n_s.html#gaf597fc0782d860be1ac1bedc5703aa1c", null ]
];