var button__internal_8h =
[
    [ "BUTTON_t", "struct_b_u_t_t_o_n__t.html", "struct_b_u_t_t_o_n__t" ],
    [ "BUT_FCLKDIV", "button__internal_8h.html#ac82f6842c9226318c3b4ef20ac5edf16", null ],
    [ "BUT_TIMER_START", "button__internal_8h.html#a999e7b88754f7d595f101ad86ad0c26a", null ],
    [ "BUT_TIMER_STOP", "button__internal_8h.html#a40e234ba4dcaa047e2cca6ffcdc02d7d", null ],
    [ "BUTTON_DEBOUNCETICKS", "button__internal_8h.html#a726e978c44a908f1acdd7128f57865b8", null ],
    [ "BUTTON_HOLDTICKS", "button__internal_8h.html#a9b16d4f8857ac6d60bb80b3414ca2605", null ]
];