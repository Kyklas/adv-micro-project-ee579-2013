var button__config_8_t_e_m_p_l_a_t_e_8h =
[
    [ "BUTTON_CLK_SRC", "button__config_8_t_e_m_p_l_a_t_e_8h.html#gad0b66e0fb32e67f7f289c4cb4274a9c7", null ],
    [ "BUTTON_DEBOUNCETIME", "button__config_8_t_e_m_p_l_a_t_e_8h.html#ga74d8196efca1807a0764b8c3c0948b8b", null ],
    [ "BUTTON_HOLDTIME", "button__config_8_t_e_m_p_l_a_t_e_8h.html#gafe644a7af161df17fef954a31d5b8e8f", null ],
    [ "BUTTON_IDIV", "button__config_8_t_e_m_p_l_a_t_e_8h.html#ga6318928039ebc940696d40e6a4ab3062", null ],
    [ "BUTTON_IDIVEX", "button__config_8_t_e_m_p_l_a_t_e_8h.html#ga5bcb70e880e93934263953cc0e6133b7", null ],
    [ "BUTTON_PORT1", "button__config_8_t_e_m_p_l_a_t_e_8h.html#ga0b5bb0c2014bfe34352dbad897e329a0", null ],
    [ "BUTTON_PORT2", "button__config_8_t_e_m_p_l_a_t_e_8h.html#gaea81cadb23f8e85e8db99124aeb16ad1", null ],
    [ "BUTTON_USE_DEV", "button__config_8_t_e_m_p_l_a_t_e_8h.html#gaf6ef5bf020e6cee889ced7fdc1bd6e55", null ]
];