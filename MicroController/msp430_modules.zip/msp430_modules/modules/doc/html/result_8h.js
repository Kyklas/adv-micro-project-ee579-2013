var result_8h =
[
    [ "RES_t", "result_8h.html#a957d8de560ce20378cca0458f04b61cc", [
      [ "RES_OK", "result_8h.html#a957d8de560ce20378cca0458f04b61cca2ea4b6ef3fffc17dd1d38ab5c2837737", null ],
      [ "RES_FAIL", "result_8h.html#a957d8de560ce20378cca0458f04b61cca56449bbc3897e24b79765be78b2f0ef1", null ],
      [ "RES_INVALID", "result_8h.html#a957d8de560ce20378cca0458f04b61cca415945752acf7689df7cb602ae4e1724", null ],
      [ "RES_NOTFOUND", "result_8h.html#a957d8de560ce20378cca0458f04b61cca2051b6d550dfb4f9217a4ee8669a560a", null ],
      [ "RES_FULL", "result_8h.html#a957d8de560ce20378cca0458f04b61cca3caf9c84fe949d40fb3f90199f87676c", null ],
      [ "RES_UNDERRUN", "result_8h.html#a957d8de560ce20378cca0458f04b61ccab6ff3fa56492fac2eae30dedf63cce42", null ],
      [ "RES_OVERRUN", "result_8h.html#a957d8de560ce20378cca0458f04b61cca8fadcf0dda5fdc72355b09ce9ca1f8b4", null ],
      [ "RES_PARAMERR", "result_8h.html#a957d8de560ce20378cca0458f04b61ccac9daf08fbd44b4037b7f4270db32da93", null ],
      [ "RES_END", "result_8h.html#a957d8de560ce20378cca0458f04b61ccaacaa9a71f1e159a1d52cae5860b108ea", null ],
      [ "RES_BUSY", "result_8h.html#a957d8de560ce20378cca0458f04b61cca0b4d219c178f001075d6fdc11cc5335f", null ],
      [ "RES_CANCEL", "result_8h.html#a957d8de560ce20378cca0458f04b61cca18792b120162554e0bf67cff49e0ca94", null ],
      [ "RES_UNKNOWN", "result_8h.html#a957d8de560ce20378cca0458f04b61cca103056b41005d7e3b9a95f8cbfbf3a08", null ]
    ] ]
];