var group___s_p_i___d_e_f_i_n_e_s =
[
    [ "SPI Modes", "group___d_e_f___s_p_i___m_o_d_e_s.html", "group___d_e_f___s_p_i___m_o_d_e_s" ],
    [ "Configuration", "group___d_e_f___s_p_i___c_o_n_f_i_g.html", "group___d_e_f___s_p_i___c_o_n_f_i_g" ]
];