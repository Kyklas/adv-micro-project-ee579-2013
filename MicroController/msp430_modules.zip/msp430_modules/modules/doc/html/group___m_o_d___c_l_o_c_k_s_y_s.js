var group___m_o_d___c_l_o_c_k_s_y_s =
[
    [ "clock_sys.c", "clock__sys_8c.html", null ],
    [ "clock_sys.h", "clock__sys_8h.html", null ],
    [ "clock_sys_config.TEMPLATE.h", "clock__sys__config_8_t_e_m_p_l_a_t_e_8h.html", null ],
    [ "clock_sys_internal.h", "clock__sys__internal_8h.html", null ],
    [ "ACLK_FREQ", "group___m_o_d___c_l_o_c_k_s_y_s.html#gae4acb2957bbcf02e0bd0db8d93d7d64f", null ],
    [ "MCLK_FREQ", "group___m_o_d___c_l_o_c_k_s_y_s.html#ga027de6fabf836f218c14bccf96002fe5", null ],
    [ "SMCLK_FREQ", "group___m_o_d___c_l_o_c_k_s_y_s.html#gac8c1536e4214841885bd4163a42ce2bd", null ],
    [ "sysInitClocks", "group___m_o_d___c_l_o_c_k_s_y_s.html#ga2ccac215f9649ee6641fd61e6cf4cde8", null ],
    [ "sysSetDivMCLK", "group___m_o_d___c_l_o_c_k_s_y_s.html#ga45aae1fb2188eeeab3df341c245e56cb", null ]
];