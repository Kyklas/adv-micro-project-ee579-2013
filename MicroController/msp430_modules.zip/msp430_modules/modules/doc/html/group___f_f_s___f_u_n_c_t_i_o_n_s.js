var group___f_f_s___f_u_n_c_t_i_o_n_s =
[
    [ "ffs_blocksFree", "group___f_f_s___f_u_n_c_t_i_o_n_s.html#gadef29c2d9aa2ff950bf4f91a15140436", null ],
    [ "ffs_cleanupFT", "group___f_f_s___f_u_n_c_t_i_o_n_s.html#gaa96151f8328186abfa63e32984f51839", null ],
    [ "ffs_countGarbageFTE", "group___f_f_s___f_u_n_c_t_i_o_n_s.html#ga062e4c718a8cc8b72f5178a83b948119", null ],
    [ "ffs_fclose", "group___f_f_s___f_u_n_c_t_i_o_n_s.html#gad30ab64900ae66c8ed55bc1eff070cbb", null ],
    [ "ffs_feof", "group___f_f_s___f_u_n_c_t_i_o_n_s.html#ga602dcfcd5ca1b1e54698f2ea723e5f48", null ],
    [ "ffs_fflush", "group___f_f_s___f_u_n_c_t_i_o_n_s.html#ga89fd92491b431cce92cecfc41be096f6", null ],
    [ "ffs_fopen", "group___f_f_s___f_u_n_c_t_i_o_n_s.html#gae35751ebb3b9addbc48309aa13fa5170", null ],
    [ "ffs_fread", "group___f_f_s___f_u_n_c_t_i_o_n_s.html#gad902218450c757f12041edf24f71b9f4", null ],
    [ "ffs_fseek", "group___f_f_s___f_u_n_c_t_i_o_n_s.html#gae2dc29df6088619e1f6980f9c0d49284", null ],
    [ "ffs_ftell", "group___f_f_s___f_u_n_c_t_i_o_n_s.html#ga21fb4ee80f9d19c0eaf1603d2369247e", null ],
    [ "ffs_fwrite", "group___f_f_s___f_u_n_c_t_i_o_n_s.html#ga7bc1e38aa5445d55b3f75b79c7f83a57", null ],
    [ "ffs_getFile", "group___f_f_s___f_u_n_c_t_i_o_n_s.html#ga87ecaf1a03aaa3a56e29212a90f7e926", null ],
    [ "ffs_init", "group___f_f_s___f_u_n_c_t_i_o_n_s.html#gaa6038b99bd2be737371f5cb56c7eb529", null ],
    [ "ffs_remove", "group___f_f_s___f_u_n_c_t_i_o_n_s.html#ga216cc58bbabece6cfb67484f721a94c4", null ]
];