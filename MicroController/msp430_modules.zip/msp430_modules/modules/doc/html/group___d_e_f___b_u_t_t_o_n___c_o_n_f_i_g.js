var group___d_e_f___b_u_t_t_o_n___c_o_n_f_i_g =
[
    [ "BUTTON_CLK_SRC", "group___d_e_f___b_u_t_t_o_n___c_o_n_f_i_g.html#gad0b66e0fb32e67f7f289c4cb4274a9c7", null ],
    [ "BUTTON_DEBOUNCETIME", "group___d_e_f___b_u_t_t_o_n___c_o_n_f_i_g.html#ga74d8196efca1807a0764b8c3c0948b8b", null ],
    [ "BUTTON_HOLDTIME", "group___d_e_f___b_u_t_t_o_n___c_o_n_f_i_g.html#gafe644a7af161df17fef954a31d5b8e8f", null ],
    [ "BUTTON_IDIV", "group___d_e_f___b_u_t_t_o_n___c_o_n_f_i_g.html#ga6318928039ebc940696d40e6a4ab3062", null ],
    [ "BUTTON_IDIVEX", "group___d_e_f___b_u_t_t_o_n___c_o_n_f_i_g.html#ga5bcb70e880e93934263953cc0e6133b7", null ],
    [ "BUTTON_PORT1", "group___d_e_f___b_u_t_t_o_n___c_o_n_f_i_g.html#ga0b5bb0c2014bfe34352dbad897e329a0", null ],
    [ "BUTTON_PORT2", "group___d_e_f___b_u_t_t_o_n___c_o_n_f_i_g.html#gaea81cadb23f8e85e8db99124aeb16ad1", null ],
    [ "BUTTON_USE_DEV", "group___d_e_f___b_u_t_t_o_n___c_o_n_f_i_g.html#gaf6ef5bf020e6cee889ced7fdc1bd6e55", null ]
];