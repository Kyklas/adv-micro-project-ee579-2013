var group___u_s_b___events =
[
    [ "onUSB_Event", "group___u_s_b___events.html#ga8813ef3719a51398915fc2857ea078fc", null ],
    [ "onUSB_InterfaceEvent", "group___u_s_b___events.html#ga63d4c29a898c4a0d59ca5949d5f7e174", null ]
];