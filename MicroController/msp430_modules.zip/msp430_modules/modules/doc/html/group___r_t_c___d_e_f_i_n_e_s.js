var group___r_t_c___d_e_f_i_n_e_s =
[
    [ "RTC Module Configuration", "group___r_t_c___d_e_f___c_f_g.html", "group___r_t_c___d_e_f___c_f_g" ],
    [ "Days of the Week", "group___d_e_f___d_o_w.html", "group___d_e_f___d_o_w" ],
    [ "Months", "group___d_e_f___m_o_n_t_h_s.html", null ],
    [ "Days of the Week Flags", "group___d_e_f___d_o_w___f_l_a_g_s.html", null ],
    [ "Alarm Mode Defines", "group___d_e_f___a_l_a_r_m___m_o_d_e.html", "group___d_e_f___a_l_a_r_m___m_o_d_e" ]
];