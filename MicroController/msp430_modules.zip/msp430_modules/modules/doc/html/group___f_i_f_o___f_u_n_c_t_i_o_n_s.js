var group___f_i_f_o___f_u_n_c_t_i_o_n_s =
[
    [ "fifo_clear", "group___f_i_f_o___f_u_n_c_t_i_o_n_s.html#ga60dbecb2750cdabe42fccb6f1449f66c", null ],
    [ "fifo_init", "group___f_i_f_o___f_u_n_c_t_i_o_n_s.html#gac66c9dec8f8e17748dfff1af5d71ac72", null ],
    [ "fifo_peek", "group___f_i_f_o___f_u_n_c_t_i_o_n_s.html#gaaea8a1af8bcfbc80a453b5e2bb444470", null ],
    [ "fifo_rdcount", "group___f_i_f_o___f_u_n_c_t_i_o_n_s.html#ga48e63b0de47c39812c5693190e74d295", null ],
    [ "fifo_read", "group___f_i_f_o___f_u_n_c_t_i_o_n_s.html#gac18f6fa63c83f0b5a21f68637e0f220c", null ],
    [ "fifo_wrcount", "group___f_i_f_o___f_u_n_c_t_i_o_n_s.html#ga4eff136f1d84ab9e06fbad65a9f3d5da", null ],
    [ "fifo_write", "group___f_i_f_o___f_u_n_c_t_i_o_n_s.html#ga62ce3dec333e205c9bdcb5788ace1e39", null ]
];