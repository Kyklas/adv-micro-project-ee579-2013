var group___m_o_d___r_o_o_t =
[
    [ "Functions", "group___r_o_o_t___functions.html", "group___r_o_o_t___functions" ],
    [ "Events", "group___r_o_o_t___e_v_e_n_t_s.html", "group___r_o_o_t___e_v_e_n_t_s" ],
    [ "Configuration", "group___d_e_f___r_o_o_t___c_o_n_f_i_g.html", "group___d_e_f___r_o_o_t___c_o_n_f_i_g" ],
    [ "root.c", "root_8c.html", null ],
    [ "root.h", "root_8h.html", null ],
    [ "root_config.TEMPLATE.h", "root__config_8_t_e_m_p_l_a_t_e_8h.html", null ]
];