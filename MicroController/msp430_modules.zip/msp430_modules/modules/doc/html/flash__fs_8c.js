var flash__fs_8c =
[
    [ "ffs_blocksFree", "flash__fs_8c.html#gadef29c2d9aa2ff950bf4f91a15140436", null ],
    [ "ffs_cleanupFT", "flash__fs_8c.html#gaa96151f8328186abfa63e32984f51839", null ],
    [ "ffs_countGarbageFTE", "flash__fs_8c.html#ga062e4c718a8cc8b72f5178a83b948119", null ],
    [ "ffs_fclose", "flash__fs_8c.html#gad30ab64900ae66c8ed55bc1eff070cbb", null ],
    [ "ffs_feof", "flash__fs_8c.html#ga602dcfcd5ca1b1e54698f2ea723e5f48", null ],
    [ "ffs_fflush", "flash__fs_8c.html#ga89fd92491b431cce92cecfc41be096f6", null ],
    [ "ffs_fopen", "flash__fs_8c.html#gae35751ebb3b9addbc48309aa13fa5170", null ],
    [ "ffs_fread", "flash__fs_8c.html#gad902218450c757f12041edf24f71b9f4", null ],
    [ "ffs_fseek", "flash__fs_8c.html#gae2dc29df6088619e1f6980f9c0d49284", null ],
    [ "ffs_ftell", "flash__fs_8c.html#ga21fb4ee80f9d19c0eaf1603d2369247e", null ],
    [ "ffs_fwrite", "flash__fs_8c.html#ga7bc1e38aa5445d55b3f75b79c7f83a57", null ],
    [ "ffs_getFile", "flash__fs_8c.html#ga87ecaf1a03aaa3a56e29212a90f7e926", null ],
    [ "ffs_init", "flash__fs_8c.html#gaa6038b99bd2be737371f5cb56c7eb529", null ],
    [ "ffs_remove", "flash__fs_8c.html#ga216cc58bbabece6cfb67484f721a94c4", null ]
];