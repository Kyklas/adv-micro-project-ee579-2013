var clock__sys__config_8_t_e_m_p_l_a_t_e_8h =
[
    [ "ACLK_DIV", "clock__sys__config_8_t_e_m_p_l_a_t_e_8h.html#a7d0b57189096aa3f0c8f39e183f2f945", null ],
    [ "ACLK_SRC", "clock__sys__config_8_t_e_m_p_l_a_t_e_8h.html#a9085a4ffbff7b104a49ad90b3808a1bf", null ],
    [ "LFXT_LOAD_CAP", "clock__sys__config_8_t_e_m_p_l_a_t_e_8h.html#a07a342fde53ecd02f84447cae36105ac", null ],
    [ "MANUAL_DCO_DCO", "clock__sys__config_8_t_e_m_p_l_a_t_e_8h.html#a04d311845104ae91e3bfa14209a4f75b", null ],
    [ "MANUAL_DCO_MOD", "clock__sys__config_8_t_e_m_p_l_a_t_e_8h.html#a3d460d9738639f401893d403939d8aa4", null ],
    [ "MANUAL_DCO_RSEL", "clock__sys__config_8_t_e_m_p_l_a_t_e_8h.html#a7338ecf130f62e36b41fd7ef70d0f458", null ],
    [ "MANUAL_FLL_REF_SRC", "clock__sys__config_8_t_e_m_p_l_a_t_e_8h.html#a5ae56b643c185ad0827c649f662161d5", null ],
    [ "MANUAL_FLLD", "clock__sys__config_8_t_e_m_p_l_a_t_e_8h.html#a8f27c66802e87f7ed9559260b452aae2", null ],
    [ "MANUAL_FLLN", "clock__sys__config_8_t_e_m_p_l_a_t_e_8h.html#a5f808af45a1640c9ca1370acd7a789c5", null ],
    [ "MANUAL_FLLREFDIV", "clock__sys__config_8_t_e_m_p_l_a_t_e_8h.html#ae1ff48afa21a68042b8b4cb9bd9ac9dc", null ],
    [ "MANUALLY_CONFIG_DCO", "clock__sys__config_8_t_e_m_p_l_a_t_e_8h.html#a2b4769ee8287fadeed3031e279e5a252", null ],
    [ "MCLK_DIV", "clock__sys__config_8_t_e_m_p_l_a_t_e_8h.html#a1c311a2e410dec36ff4e12311dfac36b", null ],
    [ "MCLK_DIV_MINIMUM_RESTRICT", "clock__sys__config_8_t_e_m_p_l_a_t_e_8h.html#a0d21e25722d86ec40a799df8b0d4cddd", null ],
    [ "MCLK_SRC", "clock__sys__config_8_t_e_m_p_l_a_t_e_8h.html#a1688f2acdf08162340fcb1851d8f5038", null ],
    [ "SMCLK_DIV", "clock__sys__config_8_t_e_m_p_l_a_t_e_8h.html#ad438077559b3efa64cf4805c76901f87", null ],
    [ "SMCLK_SRC", "clock__sys__config_8_t_e_m_p_l_a_t_e_8h.html#aefb4a0d4b360228368d57a27e001a0f9", null ],
    [ "TARGET_DCO_FREQ", "clock__sys__config_8_t_e_m_p_l_a_t_e_8h.html#aae5cbb72dcd27ca9b7d70e0be1cb9cb5", null ],
    [ "XT1_FREQ", "clock__sys__config_8_t_e_m_p_l_a_t_e_8h.html#a7fe9cbc54c3db5dfa3a9ab49239bfd61", null ],
    [ "XT2_FREQ", "clock__sys__config_8_t_e_m_p_l_a_t_e_8h.html#a5cf44ae82961c9583c9085647a7a90e4", null ]
];