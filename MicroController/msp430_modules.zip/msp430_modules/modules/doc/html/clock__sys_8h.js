var clock__sys_8h =
[
    [ "ACLK_FREQ", "clock__sys_8h.html#gae4acb2957bbcf02e0bd0db8d93d7d64f", null ],
    [ "MCLK_FREQ", "clock__sys_8h.html#ga027de6fabf836f218c14bccf96002fe5", null ],
    [ "SMCLK_FREQ", "clock__sys_8h.html#gac8c1536e4214841885bd4163a42ce2bd", null ],
    [ "sysInitClocks", "clock__sys_8h.html#ga2ccac215f9649ee6641fd61e6cf4cde8", null ],
    [ "sysSetDivMCLK", "clock__sys_8h.html#ga45aae1fb2188eeeab3df341c245e56cb", null ]
];