var group___r_o_o_t___r_e_s_e_t___r_e_a_s_o_n_s =
[
    [ "RST_BROWNOUT", "group___r_o_o_t___r_e_s_e_t___r_e_a_s_o_n_s.html#gadf2d96d8568c0a02b48c53d9033c0dcc", null ],
    [ "RST_BUTTON", "group___r_o_o_t___r_e_s_e_t___r_e_a_s_o_n_s.html#gaa7b487188034ad9947bfe70392384cda", null ],
    [ "RST_FLASH_PASSWORD", "group___r_o_o_t___r_e_s_e_t___r_e_a_s_o_n_s.html#ga7172e245198796da5d4a13d51707d755", null ],
    [ "RST_JTAG", "group___r_o_o_t___r_e_s_e_t___r_e_a_s_o_n_s.html#gad861b3960be2068e334d4155f025928a", null ],
    [ "RST_PERF", "group___r_o_o_t___r_e_s_e_t___r_e_a_s_o_n_s.html#ga37233a76988bda5cee06794a2d661390", null ],
    [ "RST_PLL_UNLOCK", "group___r_o_o_t___r_e_s_e_t___r_e_a_s_o_n_s.html#gad6d1145fda0c05d8a211e1b79d98a397", null ],
    [ "RST_PMM_PASSWORD", "group___r_o_o_t___r_e_s_e_t___r_e_a_s_o_n_s.html#ga21a59645599c9fa2779317c7d56127ad", null ],
    [ "RST_PMMSWBOR", "group___r_o_o_t___r_e_s_e_t___r_e_a_s_o_n_s.html#ga2a3ae3b4a83857cd8fb72c164e0258c8", null ],
    [ "RST_PMMSWPOR", "group___r_o_o_t___r_e_s_e_t___r_e_a_s_o_n_s.html#gaa1180432f386236cdc9533574094f758", null ],
    [ "RST_SECURITY_ERR", "group___r_o_o_t___r_e_s_e_t___r_e_a_s_o_n_s.html#ga03258d742d041236c99a239e60b91878", null ],
    [ "RST_SVMH_OVP", "group___r_o_o_t___r_e_s_e_t___r_e_a_s_o_n_s.html#ga578f909ffae8338faa7afd5613be412b", null ],
    [ "RST_SVML_OVP", "group___r_o_o_t___r_e_s_e_t___r_e_a_s_o_n_s.html#gaa35ecd833737e1584bd33eb8cba2c2ce", null ],
    [ "RST_SVSH", "group___r_o_o_t___r_e_s_e_t___r_e_a_s_o_n_s.html#gaf22beb729083a2274a01626a3d13665d", null ],
    [ "RST_SVSL", "group___r_o_o_t___r_e_s_e_t___r_e_a_s_o_n_s.html#ga3a19027542f0d3f2aef321ccc3252d6a", null ],
    [ "RST_WAKEUP", "group___r_o_o_t___r_e_s_e_t___r_e_a_s_o_n_s.html#ga487cbb075f80645f5b9c3c4f444d3c4b", null ],
    [ "RST_WDT_PASSWORD", "group___r_o_o_t___r_e_s_e_t___r_e_a_s_o_n_s.html#ga96e36b95ecbc7f6a29716efa01965e2a", null ],
    [ "RST_WDT_TIMEOUT", "group___r_o_o_t___r_e_s_e_t___r_e_a_s_o_n_s.html#ga8d9bf3107779f84e54d8768cf6197bea", null ]
];