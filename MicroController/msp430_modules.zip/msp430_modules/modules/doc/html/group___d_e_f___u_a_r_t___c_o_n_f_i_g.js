var group___d_e_f___u_a_r_t___c_o_n_f_i_g =
[
    [ "Baud Rates", "group___d_e_f___u_a_r_t___b_a_u_d_s.html", null ],
    [ "UIO_CLK_SRC", "group___d_e_f___u_a_r_t___c_o_n_f_i_g.html#ga21a9cafc2835e56d06f645518b5251f9", null ],
    [ "UIO_RXBUF_SIZE", "group___d_e_f___u_a_r_t___c_o_n_f_i_g.html#gaef31340bff3f6597cc24d67f7d9f1c8e", null ],
    [ "UIO_TXBUF_SIZE", "group___d_e_f___u_a_r_t___c_o_n_f_i_g.html#ga62337cf3b8191c49b06bfdaf2d721e38", null ],
    [ "UIO_USE_DEV", "group___d_e_f___u_a_r_t___c_o_n_f_i_g.html#gacee1a5a85017bfcad19fdab925680a13", null ],
    [ "UIO_USE_INTERRUPTS", "group___d_e_f___u_a_r_t___c_o_n_f_i_g.html#ga98983838abcef453fcab39954bbf9e81", null ]
];