var rtc_8c =
[
    [ "rtcAlarm2Time", "rtc_8c.html#ga30c2eb76ed0ad9fceca4b8b95ea9e823", null ],
    [ "rtcDeleteAlarm", "rtc_8c.html#gad2a188e4efb5b7e8c9a300deca78960a", null ],
    [ "rtcDisableAlarm", "rtc_8c.html#ga724ce31c0006288f909a7ba3ed050e98", null ],
    [ "rtcEnableAlarm", "rtc_8c.html#gacf41f55bdbf8a30a94df79b002e3453f", null ],
    [ "rtcGetAlarm", "rtc_8c.html#ga794540b092a02452e054f8a64831ee0f", null ],
    [ "rtcGetTime", "rtc_8c.html#ga8364483f472db9b25db30843a548fd39", null ],
    [ "rtcInit", "rtc_8c.html#ga5f6cddc7c2e2cbff9fcc8edc2ac6b841", null ],
    [ "rtcSetAlarm", "rtc_8c.html#gab5d7a1addff3b96181347494c70df85e", null ],
    [ "rtcSetTime", "rtc_8c.html#gaea2b56ed9ed219ba0a1ef63cbac29506", null ],
    [ "rtcTimeCmp", "rtc_8c.html#gaf597fc0782d860be1ac1bedc5703aa1c", null ]
];