var group___m_o_d___s_t_r_i_n_g___e_x_t =
[
    [ "Functions", "group___s_t_r_i_n_g___e_x_t___f_u_n_c_t_i_o_n_s.html", "group___s_t_r_i_n_g___e_x_t___f_u_n_c_t_i_o_n_s" ],
    [ "string_ext.c", "string__ext_8c.html", null ],
    [ "string_ext.h", "string__ext_8h.html", null ]
];