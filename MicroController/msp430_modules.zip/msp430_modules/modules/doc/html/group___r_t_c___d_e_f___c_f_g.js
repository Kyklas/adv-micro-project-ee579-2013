var group___r_t_c___d_e_f___c_f_g =
[
    [ "ALARM_SLOTS", "group___r_t_c___d_e_f___c_f_g.html#gad55d01ce6e6a3b9f7c828592ee5ce02d", null ],
    [ "RTC_USE_EVENT_QUEUE", "group___r_t_c___d_e_f___c_f_g.html#ga924acf4eb19c7f9e2ae0aaf4ad859015", null ]
];