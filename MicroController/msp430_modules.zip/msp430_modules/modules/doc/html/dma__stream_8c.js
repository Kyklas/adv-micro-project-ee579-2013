var dma__stream_8c =
[
    [ "dma_instream_init", "dma__stream_8c.html#ga958c795b078982368457536d7eb4bce0", null ],
    [ "dma_instream_peek", "dma__stream_8c.html#ga28c1a7e2995d488e8e5d9ee5328fb88c", null ],
    [ "dma_instream_rdcount", "dma__stream_8c.html#gaea4484fa89bc9f8dd228115085fd3656", null ],
    [ "dma_instream_read", "dma__stream_8c.html#ga38ef9cda9c47c35bb35e4665c59f5240", null ]
];