var group___r_o_o_t___e_v_e_n_t_s =
[
    [ "Reset Reasons", "group___r_o_o_t___r_e_s_e_t___r_e_a_s_o_n_s.html", "group___r_o_o_t___r_e_s_e_t___r_e_a_s_o_n_s" ],
    [ "initialize_ports", "group___r_o_o_t___e_v_e_n_t_s.html#ga280dc009199a7b36e140434a552e1735", null ],
    [ "onIdle", "group___r_o_o_t___e_v_e_n_t_s.html#ga381b2698b7cf5dbd5e844f967ec360ee", null ],
    [ "onReset", "group___r_o_o_t___e_v_e_n_t_s.html#gada39fcc9e8b7740652b34d9f1d9c38b9", null ]
];