var group___d_e_f___s_e_q_u_e_n_c_e_r___c_o_n_f_i_g =
[
    [ "EVENT_TIMER_SLOTS", "group___d_e_f___s_e_q_u_e_n_c_e_r___c_o_n_f_i_g.html#ga49283f10755d277d10398102e763b9fd", null ],
    [ "SEQUENCER_CLK_SRC", "group___d_e_f___s_e_q_u_e_n_c_e_r___c_o_n_f_i_g.html#gae1c57708de856d0858a5e48f1f6e33e9", null ],
    [ "SEQUENCER_IDIV", "group___d_e_f___s_e_q_u_e_n_c_e_r___c_o_n_f_i_g.html#gae4d63e1a0ae45e0434d79470a3a9a68e", null ],
    [ "SEQUENCER_IDIVEX", "group___d_e_f___s_e_q_u_e_n_c_e_r___c_o_n_f_i_g.html#ga3dd853dc665f6e884da088ebdcd536cc", null ],
    [ "SEQUENCER_MAXLEN", "group___d_e_f___s_e_q_u_e_n_c_e_r___c_o_n_f_i_g.html#gafe411e4f293f42dfaaeea6266a6bbe84", null ],
    [ "SEQUENCER_SLOTS", "group___d_e_f___s_e_q_u_e_n_c_e_r___c_o_n_f_i_g.html#ga1ad42de8fd9a640c276275b688446ab7", null ],
    [ "SEQUENCER_USE_DEV", "group___d_e_f___s_e_q_u_e_n_c_e_r___c_o_n_f_i_g.html#ga95cf56a61bee36b95f3531879a599653", null ]
];