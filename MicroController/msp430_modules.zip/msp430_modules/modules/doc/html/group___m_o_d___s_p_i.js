var group___m_o_d___s_p_i =
[
    [ "Functions", "group___s_p_i___f_u_n_c_t_i_o_n_s.html", "group___s_p_i___f_u_n_c_t_i_o_n_s" ],
    [ "Defines", "group___s_p_i___d_e_f_i_n_e_s.html", "group___s_p_i___d_e_f_i_n_e_s" ],
    [ "spi.c", "spi_8c.html", null ],
    [ "spi.h", "spi_8h.html", null ],
    [ "spi_config.TEMPLATE.h", "spi__config_8_t_e_m_p_l_a_t_e_8h.html", null ],
    [ "spi_internal.h", "spi__internal_8h.html", null ]
];