var group___m_o_d___d_m_a___s_t_r_e_a_m =
[
    [ "DMA_INSTREAM_t", "struct_d_m_a___i_n_s_t_r_e_a_m__t.html", null ],
    [ "DMA_OUTSTREAM_t", "struct_d_m_a___o_u_t_s_t_r_e_a_m__t.html", null ],
    [ "Functions", "group___d_m_a_s_t_r_e_a_m___f_u_n_c_t_i_o_n_s.html", "group___d_m_a_s_t_r_e_a_m___f_u_n_c_t_i_o_n_s" ],
    [ "dma_stream.c", "dma__stream_8c.html", null ],
    [ "dma_stream.h", "dma__stream_8h.html", null ]
];