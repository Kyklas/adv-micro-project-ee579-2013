var group___s_p_i___f_u_n_c_t_i_o_n_s =
[
    [ "spiGetByte", "group___s_p_i___f_u_n_c_t_i_o_n_s.html#ga70c5dd1aa1193eaedab17c8025cc50d5", null ],
    [ "spiInit", "group___s_p_i___f_u_n_c_t_i_o_n_s.html#gaa196c2f56a26a5a174a8257f5a17afdd", null ],
    [ "spiReadFrame", "group___s_p_i___f_u_n_c_t_i_o_n_s.html#gaf4dfa07ce586a0b439aa49532933d6aa", null ],
    [ "spiSendByte", "group___s_p_i___f_u_n_c_t_i_o_n_s.html#ga73b97cdc9b50b51d3fabe5c0dec0ae15", null ],
    [ "spiSendFrame", "group___s_p_i___f_u_n_c_t_i_o_n_s.html#ga039a99b5fdaabc3e246d50eb3dfb2370", null ]
];