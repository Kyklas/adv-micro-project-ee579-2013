var group___b_t___e_v_e_n_t_s =
[
    [ "onBT_Disconnect", "group___b_t___e_v_e_n_t_s.html#gaf835c7625c184b1d22021ac9f6e482f5", null ],
    [ "onBT_HFPRingStart", "group___b_t___e_v_e_n_t_s.html#gadbd685f37240e89f2ba2b4a5d82dc788", null ],
    [ "onBT_HFPRingStop", "group___b_t___e_v_e_n_t_s.html#ga8da93beed5ab2312b47f128b6135378e", null ],
    [ "onBT_OtherEvent", "group___b_t___e_v_e_n_t_s.html#ga2f809eb38e4503dc2e32d7f2ff687f2c", null ],
    [ "onBT_Pair", "group___b_t___e_v_e_n_t_s.html#ga8bdc89ac0cc4ef0b30a8fe69836ffedb", null ],
    [ "onBT_Ring", "group___b_t___e_v_e_n_t_s.html#ga185661c6c2ba5d136e1767f0903af8c3", null ],
    [ "onBT_SPPNewline", "group___b_t___e_v_e_n_t_s.html#ga655e6cf6ec5117d895134e24a0b09f70", null ],
    [ "onBT_SPPThreshold", "group___b_t___e_v_e_n_t_s.html#ga65f157c6dd50589094b739c219b9656d", null ]
];