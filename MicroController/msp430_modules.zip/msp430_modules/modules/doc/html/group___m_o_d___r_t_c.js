var group___m_o_d___r_t_c =
[
    [ "TIME_t", "struct_t_i_m_e__t.html", null ],
    [ "ALARM_t", "struct_a_l_a_r_m__t.html", null ],
    [ "Functions", "group___r_t_c___f_u_n_c_t_i_o_n_s.html", "group___r_t_c___f_u_n_c_t_i_o_n_s" ],
    [ "Defines", "group___r_t_c___d_e_f_i_n_e_s.html", "group___r_t_c___d_e_f_i_n_e_s" ],
    [ "Events", "group___r_t_c___e_v_e_n_t_s.html", null ],
    [ "rtc.c", "rtc_8c.html", null ],
    [ "rtc.h", "rtc_8h.html", null ]
];