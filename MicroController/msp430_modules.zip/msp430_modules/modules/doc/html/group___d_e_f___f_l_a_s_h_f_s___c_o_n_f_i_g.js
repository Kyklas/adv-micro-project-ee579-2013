var group___d_e_f___f_l_a_s_h_f_s___c_o_n_f_i_g =
[
    [ "FFS_CLEANUP_FT_MODE", "group___d_e_f___f_l_a_s_h_f_s___c_o_n_f_i_g.html#gaf6518de0b16049b638004bf73d315c61", null ],
    [ "FFS_ERASE_VAL", "group___d_e_f___f_l_a_s_h_f_s___c_o_n_f_i_g.html#gaa351e90ad00a306dc5b51cf7488f7aec", null ],
    [ "FFS_FILENAME_LEN", "group___d_e_f___f_l_a_s_h_f_s___c_o_n_f_i_g.html#ga5e34742f4990d48a010f99f08a39b8a1", null ]
];