var root__config_8_t_e_m_p_l_a_t_e_8h =
[
    [ "EVENT_QUEUE_SIZE", "root__config_8_t_e_m_p_l_a_t_e_8h.html#ga3d16e5de491dfd7c361575b398679dd3", null ],
    [ "MAX_YIELD_DEPTH", "root__config_8_t_e_m_p_l_a_t_e_8h.html#ga1615e79df1ecc954e52eb71c7905eddf", null ],
    [ "USE_WATCHDOG", "root__config_8_t_e_m_p_l_a_t_e_8h.html#ga71be4a990011c7b00830abf5f3b2190d", null ]
];