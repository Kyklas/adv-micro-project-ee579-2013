var group___r_o_o_t___functions =
[
    [ "FEED_WATCHDOG", "group___r_o_o_t___functions.html#gaacf80200d6bd7382d32cdf35c75eef7e", null ],
    [ "root_PopEventData", "group___r_o_o_t___functions.html#gafc1d54235e5fbcbec826419b44769808", null ],
    [ "root_PushEvent", "group___r_o_o_t___functions.html#ga7543aa03d6d2c87bf009be3de873cf1e", null ],
    [ "root_ResetReasonString", "group___r_o_o_t___functions.html#ga808414caeacd1c29cc29888e51d0db7d", null ],
    [ "root_StartRootProcess", "group___r_o_o_t___functions.html#ga3250142bdd7576ff35fe337645c8a75a", null ],
    [ "root_YieldEvent", "group___r_o_o_t___functions.html#gac3a188d53345bbfa53c0a89d3e1292c6", null ]
];