var group___d_m_a_s_t_r_e_a_m___f_u_n_c_t_i_o_n_s =
[
    [ "dma_instream_init", "group___d_m_a_s_t_r_e_a_m___f_u_n_c_t_i_o_n_s.html#ga958c795b078982368457536d7eb4bce0", null ],
    [ "dma_instream_peek", "group___d_m_a_s_t_r_e_a_m___f_u_n_c_t_i_o_n_s.html#ga28c1a7e2995d488e8e5d9ee5328fb88c", null ],
    [ "dma_instream_rdcount", "group___d_m_a_s_t_r_e_a_m___f_u_n_c_t_i_o_n_s.html#gaea4484fa89bc9f8dd228115085fd3656", null ],
    [ "dma_instream_read", "group___d_m_a_s_t_r_e_a_m___f_u_n_c_t_i_o_n_s.html#ga38ef9cda9c47c35bb35e4665c59f5240", null ]
];