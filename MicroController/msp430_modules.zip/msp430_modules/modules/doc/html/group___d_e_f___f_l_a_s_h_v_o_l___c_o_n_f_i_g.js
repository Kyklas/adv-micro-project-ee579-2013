var group___d_e_f___f_l_a_s_h_v_o_l___c_o_n_f_i_g =
[
    [ "FLASH_BLOCKSIZE", "group___d_e_f___f_l_a_s_h_v_o_l___c_o_n_f_i_g.html#ga104d5dd06137e41c83a022a022ff774c", null ],
    [ "FLASH_DEVICECOUNT", "group___d_e_f___f_l_a_s_h_v_o_l___c_o_n_f_i_g.html#gaa4bf3c166bc3786419ddd2c30f3e9099", null ]
];