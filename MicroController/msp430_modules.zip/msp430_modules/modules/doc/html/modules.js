var modules =
[
    [ "Pushbutton Events", "group___m_o_d___b_u_t_t_o_n.html", "group___m_o_d___b_u_t_t_o_n" ],
    [ "Clock System", "group___m_o_d___c_l_o_c_k_s_y_s.html", "group___m_o_d___c_l_o_c_k_s_y_s" ],
    [ "Command Line Interface", "group___m_o_d___c_l_i.html", "group___m_o_d___c_l_i" ],
    [ "DMA Stream", "group___m_o_d___d_m_a___s_t_r_e_a_m.html", "group___m_o_d___d_m_a___s_t_r_e_a_m" ],
    [ "FIFO Datapipe", "group___m_o_d___f_i_f_o.html", "group___m_o_d___f_i_f_o" ],
    [ "Flash File System", "group___m_o_d___f_l_a_s_h_f_s.html", "group___m_o_d___f_l_a_s_h_f_s" ],
    [ "Spanned Flash Memory Volume", "group___m_o_d___f_l_a_s_h_s_p_a_n.html", "group___m_o_d___f_l_a_s_h_s_p_a_n" ],
    [ "Root", "group___m_o_d___r_o_o_t.html", "group___m_o_d___r_o_o_t" ],
    [ "Real-time Clock", "group___m_o_d___r_t_c.html", "group___m_o_d___r_t_c" ],
    [ "Output Sequencer & Event Timer", "group___m_o_d___s_e_q_u_e_n_c_e_r.html", "group___m_o_d___s_e_q_u_e_n_c_e_r" ],
    [ "Sleep", "group___m_o_d___s_l_e_e_p.html", "group___m_o_d___s_l_e_e_p" ],
    [ "SPI Bus", "group___m_o_d___s_p_i.html", "group___m_o_d___s_p_i" ],
    [ "SST25VF Serial Flash", "group___m_o_d___s_s_t25_v_f.html", "group___m_o_d___s_s_t25_v_f" ],
    [ "Extended String Functions", "group___m_o_d___s_t_r_i_n_g___e_x_t.html", "group___m_o_d___s_t_r_i_n_g___e_x_t" ],
    [ "UART IO", "group___m_o_d___u_a_r_t.html", "group___m_o_d___u_a_r_t" ]
];