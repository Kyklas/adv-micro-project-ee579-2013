var group___d_e_f___s_p_i___m_o_d_e_s =
[
    [ "SPI_MODE0", "group___d_e_f___s_p_i___m_o_d_e_s.html#gac9d0bde2b42b2403d00b7a611514b006", null ],
    [ "SPI_MODE1", "group___d_e_f___s_p_i___m_o_d_e_s.html#ga9481b7327b91aa52ff5f70eb2d0acc95", null ],
    [ "SPI_MODE2", "group___d_e_f___s_p_i___m_o_d_e_s.html#ga991dec04d2fb38979cfb0d9fc7f8b026", null ],
    [ "SPI_MODE3", "group___d_e_f___s_p_i___m_o_d_e_s.html#ga5f928a2445070981765ee0416c12369d", null ]
];