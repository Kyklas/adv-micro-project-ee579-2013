var group___m_o_d___f_i_f_o =
[
    [ "FIFO_t", "struct_f_i_f_o__t.html", null ],
    [ "Functions", "group___f_i_f_o___f_u_n_c_t_i_o_n_s.html", "group___f_i_f_o___f_u_n_c_t_i_o_n_s" ],
    [ "fifo.c", "fifo_8c.html", null ],
    [ "fifo.h", "fifo_8h.html", null ],
    [ "FIFO_LOG_MAX_USAGE", "group___m_o_d___f_i_f_o.html#ga8bd8fdf7e529be1830e1b1ac4abc33fb", null ]
];