var group___b_t___config =
[
    [ "BT_CMDBUF_SIZE", "group___b_t___config.html#ga13fb8aacdaa2aac6119d4153754eaca3", null ],
    [ "BT_RXBUF_SIZE", "group___b_t___config.html#gaf9d825ad111ce2a59b67e3fd36d0d938", null ]
];