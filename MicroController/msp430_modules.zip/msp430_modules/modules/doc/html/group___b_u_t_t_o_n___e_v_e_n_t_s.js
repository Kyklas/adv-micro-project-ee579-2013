var group___b_u_t_t_o_n___e_v_e_n_t_s =
[
    [ "onButtonDown", "group___b_u_t_t_o_n___e_v_e_n_t_s.html#gac39c578a481cc9fae18244df630c5ffa", null ],
    [ "onButtonHold", "group___b_u_t_t_o_n___e_v_e_n_t_s.html#ga61f25646f0b5a07c6e0ea6d970de31b1", null ],
    [ "onButtonUp", "group___b_u_t_t_o_n___e_v_e_n_t_s.html#ga9b5c1ebd17957ac1f586288ba9b81db9", null ]
];