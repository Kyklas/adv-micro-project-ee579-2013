var group___s_s_t25_v_f___d_e_f_i_n_e_s =
[
    [ "Status Register Bits", "group___s_s_t25_v_f___d_e_f___s_r.html", null ],
    [ "Commands", "group___s_s_t25_v_f___d_e_f___c_m_d.html", null ],
    [ "Device IDs", "group___s_s_t25_v_f___d_e_f___i_d.html", null ],
    [ "Device JEDEC IDs", "group___s_s_t25_v_f___d_e_f___j_e_d_e_c.html", null ],
    [ "Device Sizes", "group___s_s_t25_v_f___d_e_f___s_i_z_e.html", null ],
    [ "Configuration", "group___d_e_f___s_s_t25_v_f___c_o_n_f_i_g.html", "group___d_e_f___s_s_t25_v_f___c_o_n_f_i_g" ]
];