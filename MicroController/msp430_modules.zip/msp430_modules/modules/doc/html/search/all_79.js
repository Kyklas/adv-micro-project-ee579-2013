var searchData=
[
  ['year',['year',['../struct_t_i_m_e__t.html#a57ca98d8f6d4baf0fe41c583c7dcb0d5',1,'TIME_t']]]
];
