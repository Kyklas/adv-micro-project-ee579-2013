var searchData=
[
  ['usleep',['usleep',['../group___m_o_d___s_l_e_e_p.html#ga2dbbec8f8aa35da271530d6d138f2c5e',1,'sleep.c']]]
];
