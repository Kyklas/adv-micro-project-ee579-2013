var searchData=
[
  ['en_5fbinary',['en_binary',['../struct_b_t___s_p_p__t.html#a4ba0dba867d640205c881b2d7d63ccc6',1,'BT_SPP_t']]]
];
