var searchData=
[
  ['root_5fpopeventdata',['root_PopEventData',['../group___r_o_o_t___functions.html#gafc1d54235e5fbcbec826419b44769808',1,'root.c']]],
  ['root_5fpushevent',['root_PushEvent',['../group___r_o_o_t___functions.html#ga7543aa03d6d2c87bf009be3de873cf1e',1,'root.c']]],
  ['root_5fresetreasonstring',['root_ResetReasonString',['../group___r_o_o_t___functions.html#ga808414caeacd1c29cc29888e51d0db7d',1,'root.c']]],
  ['root_5fstartrootprocess',['root_StartRootProcess',['../group___r_o_o_t___functions.html#ga3250142bdd7576ff35fe337645c8a75a',1,'root.c']]],
  ['root_5fyieldevent',['root_YieldEvent',['../group___r_o_o_t___functions.html#gac3a188d53345bbfa53c0a89d3e1292c6',1,'root.c']]],
  ['rtcalarm2time',['rtcAlarm2Time',['../group___r_t_c___f_u_n_c_t_i_o_n_s.html#ga30c2eb76ed0ad9fceca4b8b95ea9e823',1,'rtc.c']]],
  ['rtcdeletealarm',['rtcDeleteAlarm',['../group___r_t_c___f_u_n_c_t_i_o_n_s.html#gad2a188e4efb5b7e8c9a300deca78960a',1,'rtc.c']]],
  ['rtcdisablealarm',['rtcDisableAlarm',['../group___r_t_c___f_u_n_c_t_i_o_n_s.html#ga724ce31c0006288f909a7ba3ed050e98',1,'rtc.c']]],
  ['rtcenablealarm',['rtcEnableAlarm',['../group___r_t_c___f_u_n_c_t_i_o_n_s.html#gacf41f55bdbf8a30a94df79b002e3453f',1,'rtc.c']]],
  ['rtcgetalarm',['rtcGetAlarm',['../group___r_t_c___f_u_n_c_t_i_o_n_s.html#ga794540b092a02452e054f8a64831ee0f',1,'rtc.c']]],
  ['rtcgettime',['rtcGetTime',['../group___r_t_c___f_u_n_c_t_i_o_n_s.html#ga8364483f472db9b25db30843a548fd39',1,'rtc.c']]],
  ['rtcinit',['rtcInit',['../group___r_t_c___f_u_n_c_t_i_o_n_s.html#ga5f6cddc7c2e2cbff9fcc8edc2ac6b841',1,'rtc.c']]],
  ['rtcsetalarm',['rtcSetAlarm',['../group___r_t_c___f_u_n_c_t_i_o_n_s.html#gab5d7a1addff3b96181347494c70df85e',1,'rtc.c']]],
  ['rtcsettime',['rtcSetTime',['../group___r_t_c___f_u_n_c_t_i_o_n_s.html#gaea2b56ed9ed219ba0a1ef63cbac29506',1,'rtc.c']]],
  ['rtctimecmp',['rtcTimeCmp',['../group___r_t_c___f_u_n_c_t_i_o_n_s.html#gaf597fc0782d860be1ac1bedc5703aa1c',1,'rtc.c']]]
];
