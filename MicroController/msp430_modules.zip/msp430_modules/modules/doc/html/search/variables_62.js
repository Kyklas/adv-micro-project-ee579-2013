var searchData=
[
  ['blockcount',['BlockCount',['../structflash_s_p_a_n__t.html#af82e1ab901fde9d4958f6217dec1c403',1,'flashSPAN_t']]]
];
