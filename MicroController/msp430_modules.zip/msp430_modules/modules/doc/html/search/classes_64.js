var searchData=
[
  ['dma_5fchannel_5ft',['DMA_CHANNEL_t',['../struct_d_m_a___c_h_a_n_n_e_l__t.html',1,'']]],
  ['dma_5finstream_5ft',['DMA_INSTREAM_t',['../struct_d_m_a___i_n_s_t_r_e_a_m__t.html',1,'']]],
  ['dma_5foutstream_5ft',['DMA_OUTSTREAM_t',['../struct_d_m_a___o_u_t_s_t_r_e_a_m__t.html',1,'']]]
];
