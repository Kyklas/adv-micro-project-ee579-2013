var searchData=
[
  ['getc',['getc',['../group___u_a_r_t___f_u_n_c_t_i_o_n_s.html#ga85914aa616a3d3af4d94ca8c93ba78dc',1,'uart_io.c']]],
  ['getline',['getline',['../group___u_a_r_t___f_u_n_c_t_i_o_n_s.html#gaf3fddb91a0d7ce46a700527afbfe30b0',1,'uart_io.c']]]
];
