var searchData=
[
  ['day',['day',['../struct_t_i_m_e__t.html#a72369a1087b2aeffe374bb054cb97c12',1,'TIME_t::day()'],['../struct_a_l_a_r_m__t.html#a72369a1087b2aeffe374bb054cb97c12',1,'ALARM_t::day()']]],
  ['dayofweek',['dayofweek',['../struct_t_i_m_e__t.html#af19fd1d4c2d4e9354c68c3b5546b7d41',1,'TIME_t']]],
  ['deviceblocks',['DeviceBlocks',['../structflash_s_p_a_n__t.html#aee4775e6290c05739cad3e3d39b6cc6d',1,'flashSPAN_t']]],
  ['dow_5fflags',['dow_flags',['../struct_a_l_a_r_m__t.html#ae489adc267e8812e570220be305afaa3',1,'ALARM_t']]]
];
