var searchData=
[
  ['uart_20io',['UART IO',['../group___m_o_d___u_a_r_t.html',1,'']]],
  ['uart_5fio_2ec',['uart_io.c',['../uart__io_8c.html',1,'']]],
  ['uart_5fio_2eh',['uart_io.h',['../uart__io_8h.html',1,'']]],
  ['uart_5fio_5fconfig_2etemplate_2eh',['uart_io_config.TEMPLATE.h',['../uart__io__config_8_t_e_m_p_l_a_t_e_8h.html',1,'']]],
  ['uart_5fio_5finternal_2eh',['uart_io_internal.h',['../uart__io__internal_8h.html',1,'']]],
  ['uio_5fclk_5fsrc',['UIO_CLK_SRC',['../group___d_e_f___u_a_r_t___c_o_n_f_i_g.html#ga21a9cafc2835e56d06f645518b5251f9',1,'uart_io_config.TEMPLATE.h']]],
  ['uio_5frxbuf_5fsize',['UIO_RXBUF_SIZE',['../group___d_e_f___u_a_r_t___c_o_n_f_i_g.html#gaef31340bff3f6597cc24d67f7d9f1c8e',1,'uart_io_config.TEMPLATE.h']]],
  ['uio_5ftxbuf_5fsize',['UIO_TXBUF_SIZE',['../group___d_e_f___u_a_r_t___c_o_n_f_i_g.html#ga62337cf3b8191c49b06bfdaf2d721e38',1,'uart_io_config.TEMPLATE.h']]],
  ['uio_5fuse_5fdev',['UIO_USE_DEV',['../group___d_e_f___u_a_r_t___c_o_n_f_i_g.html#gacee1a5a85017bfcad19fdab925680a13',1,'uart_io_config.TEMPLATE.h']]],
  ['uio_5fuse_5finterrupts',['UIO_USE_INTERRUPTS',['../group___d_e_f___u_a_r_t___c_o_n_f_i_g.html#ga98983838abcef453fcab39954bbf9e81',1,'uart_io_config.TEMPLATE.h']]],
  ['unknown_5fdow',['UNKNOWN_DOW',['../group___d_e_f___d_o_w.html#gac64b040d08de903984c115e37a6cdb3a',1,'rtc.h']]],
  ['use_5fwatchdog',['USE_WATCHDOG',['../group___d_e_f___r_o_o_t___c_o_n_f_i_g.html#ga71be4a990011c7b00830abf5f3b2190d',1,'root_config.TEMPLATE.h']]],
  ['usleep',['usleep',['../group___m_o_d___s_l_e_e_p.html#ga2dbbec8f8aa35da271530d6d138f2c5e',1,'sleep.c']]]
];
