var searchData=
[
  ['root',['Root',['../group___m_o_d___r_o_o_t.html',1,'']]],
  ['real_2dtime_20clock',['Real-time Clock',['../group___m_o_d___r_t_c.html',1,'']]],
  ['reset_20reasons',['Reset Reasons',['../group___r_o_o_t___r_e_s_e_t___r_e_a_s_o_n_s.html',1,'']]],
  ['rtc_20module_20configuration',['RTC Module Configuration',['../group___r_t_c___d_e_f___c_f_g.html',1,'']]]
];
