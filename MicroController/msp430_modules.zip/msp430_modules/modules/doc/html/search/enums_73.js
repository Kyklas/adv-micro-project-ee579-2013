var searchData=
[
  ['spp_5fmode_5fe',['SPP_MODE_e',['../group___b_t___d_e_f_i_n_i_t_i_o_n_s.html#ga82828f20fc2b57490ac45ccc2e90b8b5',1,'bt.h']]]
];
