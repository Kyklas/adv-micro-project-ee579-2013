var searchData=
[
  ['spi_20modes',['SPI Modes',['../group___d_e_f___s_p_i___m_o_d_e_s.html',1,'']]],
  ['spanned_20flash_20memory_20volume',['Spanned Flash Memory Volume',['../group___m_o_d___f_l_a_s_h_s_p_a_n.html',1,'']]],
  ['spanned_20sst25vf_20serial_20flash_20volume',['Spanned SST25VF Serial Flash Volume',['../group___m_o_d___f_l_a_s_h_s_p_a_n___s_s_t25_v_f.html',1,'']]],
  ['sleep',['Sleep',['../group___m_o_d___s_l_e_e_p.html',1,'']]],
  ['spi_20bus',['SPI Bus',['../group___m_o_d___s_p_i.html',1,'']]],
  ['sst25vf_20serial_20flash',['SST25VF Serial Flash',['../group___m_o_d___s_s_t25_v_f.html',1,'']]],
  ['status_20register_20bits',['Status Register Bits',['../group___s_s_t25_v_f___d_e_f___s_r.html',1,'']]]
];
