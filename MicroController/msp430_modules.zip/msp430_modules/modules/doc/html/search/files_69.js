var searchData=
[
  ['isr_5fxc_2eh',['isr_xc.h',['../isr__xc_8h.html',1,'']]]
];
