var dma__stream_8h =
[
    [ "DMA_INSTREAM_t", "struct_d_m_a___i_n_s_t_r_e_a_m__t.html", "struct_d_m_a___i_n_s_t_r_e_a_m__t" ],
    [ "DMA_OUTSTREAM_t", "struct_d_m_a___o_u_t_s_t_r_e_a_m__t.html", "struct_d_m_a___o_u_t_s_t_r_e_a_m__t" ],
    [ "dma_instream_init", "dma__stream_8h.html#ga958c795b078982368457536d7eb4bce0", null ],
    [ "dma_instream_peek", "dma__stream_8h.html#ga28c1a7e2995d488e8e5d9ee5328fb88c", null ],
    [ "dma_instream_rdcount", "dma__stream_8h.html#gaea4484fa89bc9f8dd228115085fd3656", null ],
    [ "dma_instream_read", "dma__stream_8h.html#ga38ef9cda9c47c35bb35e4665c59f5240", null ],
    [ "dma_outstream_init", "dma__stream_8h.html#ga3ed3b76d7fe8e55ae27f1ece780961c6", null ],
    [ "dma_outstream_wrcount", "dma__stream_8h.html#ga6abffbd2838f2107685cfcada93a0ee0", null ],
    [ "dma_outstream_write", "dma__stream_8h.html#gae8d8ad2ffe307f8ab186e6039bdc2602", null ]
];