var group___d_e_f___r_o_o_t___c_o_n_f_i_g =
[
    [ "EVENT_QUEUE_SIZE", "group___d_e_f___r_o_o_t___c_o_n_f_i_g.html#ga3d16e5de491dfd7c361575b398679dd3", null ],
    [ "MAX_YIELD_DEPTH", "group___d_e_f___r_o_o_t___c_o_n_f_i_g.html#ga1615e79df1ecc954e52eb71c7905eddf", null ],
    [ "USE_WATCHDOG", "group___d_e_f___r_o_o_t___c_o_n_f_i_g.html#ga71be4a990011c7b00830abf5f3b2190d", null ]
];