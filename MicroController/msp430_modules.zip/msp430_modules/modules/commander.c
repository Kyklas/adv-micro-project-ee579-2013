/*
* Copyright (c) 2012, Alexander I. Mykyta
* All rights reserved.
* 
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met: 
* 
* 1. Redistributions of source code must retain the above copyright notice, this
*    list of conditions and the following disclaimer. 
* 2. Redistributions in binary form must reproduce the above copyright notice,
*    this list of conditions and the following disclaimer in the documentation
*    and/or other materials provided with the distribution. 
* 
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
* ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

/*==================================================================================================
* File History:
* NAME          DATE         COMMENTS
* Alex M.       01/04/2011   born
* 
*=================================================================================================*/

/**
* \addtogroup MOD_CLI
* \{
**/

/**
* \file
* \brief Code for \ref MOD_CLI "Command Line Interface"
* \author Alex Mykyta (amykyta3@gmail.com)
**/

#include <stdint.h>
#include <string.h>

#include "commander.h"
#include "commander_commands.h"

const CMDENTRY_t CommandTable[] = {CMDTABLE};
void cmd_disable_input_processing(void);
void cmd_enable_input_processing(void);

#define CMDCOUNT	(sizeof(CommandTable)/sizeof(CMDENTRY_t))
#ifdef __CYGWIN32__
	#define CMD_BACKSPACE_KEY	0x7F
#else
	#define CMD_BACKSPACE_KEY	'\b'
#endif

//--------------------------------------------------------------------------------------------------
// internal
static uint8_t first_word_equal(char *sentence, char *word){
	int i = 0;
	
	while(1){
		if((word[i] == 0) && ((sentence[i] == 0) || (sentence[i] == ' '))){
			// reached end of words without failing
			return(1);
		}
		
		if(sentence[i] != word[i]){
			return(0);
		}
		i++;
		
	}
}

//--------------------------------------------------------------------------------------------------
/** 
* \brief Incoming character processing function.
* 
* Pass each incoming character into this function. Strings are parsed and the appropriate command
* function is called. Any following words are passed in as arguments.
**/
void cmd_ProcessChar(char inchar){
	static char strin[MAX_CMDINBUF];
	static uint8_t stridx = 0;
	static uint8_t cmd_active = 0;
	static size_t current_cmdidx;
	CMDRES_t cmd_result;
	
	#if CMD_MAX_ARGV != 0
		char *argv[CMD_MAX_ARGV];
		uint8_t argc;
		uint8_t rdidx,wridx;
	#else
		char *argv[1] = strin;
	#endif
	
	
	if(cmd_active){ // A command is currently active. Redirect inchar to the command
		strin[0] = inchar;
		strin[1] = 0;
		argv[0] = strin;

		cmd_disable_input_processing();
		cmd_result = (*CommandTable[current_cmdidx].cmdptr)(1,argv,0); // Execute command
		cmd_enable_input_processing();

		switch(cmd_result){
			case CMD_EXIT:
				cmd_active = 0;
				cmd_puts("\r\n>");
				break;
			case CMD_CONTINUE:
				cmd_active = 1;
				break;
		}
	}else{
		if(inchar == '\r'){ // recvd return
			// Process Command
			strin[stridx] = 0; // null terminate
			
			if(stridx != 0){
				cmd_puts("\r\n");
				current_cmdidx = 0;
				while(1){ // search for matching command word
					//if(!strcmp(strin,CommandTable[current_cmdidx].strCommand)){
					if(first_word_equal(strin,CommandTable[current_cmdidx].strCommand)){
						// found a match

						#if CMD_MAX_ARGV != 0
							// Split strin into argv table.
							wridx = 0;
							rdidx = 0;
							argc = 1;
							argv[0] = strin;
							while(strin[rdidx] != 0){
								if(strin[rdidx] == '"'){
									rdidx++;
								}else if((strin[rdidx] == ' ') && (((rdidx - wridx) % 2) == 0)){
									// found space outside of quotations: Argument separator
									strin[wridx] = 0;
									rdidx++;
									wridx++;
									if(argc == CMD_MAX_ARGV-1) break;
									argv[argc] = &strin[wridx];
									argc++;
								}else{
									strin[wridx] = strin[rdidx];
									rdidx++;
									wridx++;
								}
							}
							strin[wridx] = 0;
							
							cmd_disable_input_processing();
							cmd_result = (*CommandTable[current_cmdidx].cmdptr)(argc,argv,1); // Execute command
							cmd_enable_input_processing();
						#else
							cmd_disable_input_processing();
							cmd_result = (*CommandTable[current_cmdidx].cmdptr)(1,argv,1); // Execute command
							cmd_enable_input_processing();
						#endif
						switch(cmd_result){
							case CMD_EXIT:
								cmd_active = 0;
								cmd_puts("\r\n>");
								break;
							case CMD_CONTINUE:
								cmd_active = 1;
								break;
						}
						break;
					}else{
						current_cmdidx++;
					}
					if(current_cmdidx >= CMDCOUNT){
						cmd_puts("Command not found\r\n\n>");
						break;
					}
				}
			}else{
				cmd_puts("\r\n>");
			}
			
			stridx = 0;
		}else if(inchar == CMD_BACKSPACE_KEY){ // Backspace Key
			if(stridx != 0){
				stridx--;
				cmd_puts("\b \b");
			}
		}else if(inchar == '\n'){
			// discard line feed characters.
		}else{
			if(stridx < MAX_CMDINBUF){
				strin[stridx++] = inchar;
				cmd_putc(inchar);
			}
		}
	}	
}

///\}
