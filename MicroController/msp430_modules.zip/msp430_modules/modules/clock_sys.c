/*
* Copyright (c) 2012, Alexander I. Mykyta
* All rights reserved.
* 
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met: 
* 
* 1. Redistributions of source code must retain the above copyright notice, this
*    list of conditions and the following disclaimer. 
* 2. Redistributions in binary form must reproduce the above copyright notice,
*    this list of conditions and the following disclaimer in the documentation
*    and/or other materials provided with the distribution. 
* 
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
* ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

/*==================================================================================================
* File History:
* NAME          DATE         COMMENTS
* Alex M.       09/19/2011   born
* 
*=================================================================================================*/

/**
* \addtogroup MOD_CLOCKSYS
* \{
**/

/**
* \file
* \brief Code for \ref MOD_CLOCKSYS "Clock System"
* \author Alex Mykyta (amykyta3@gmail.com)
**/

///\}

#include <stdint.h>
#include <msp430_xc.h>
#include "clock_sys.h"

//##################################################################################################
//# Basic Clock Module                                                                             #
//# 1xx Devices                                                                                    #
//##################################################################################################
#ifdef __MSP430_HAS_BASIC_CLOCK__
	
#endif
//##################################################################################################
//# Basic Clock Module+                                                                            #
//# 2xx Devices                                                                                    #
//##################################################################################################
#ifdef __MSP430_HAS_BC2__
	
#endif
//##################################################################################################
//# Unified Clock System (UCS)                                                                     #
//# 5xx and 6xx Devices                                                                            #
//##################################################################################################
#ifdef __MSP430_HAS_UCS__

#include "HAL_TI/HAL_PMM.h"

RES_t sysSetDivMCLK(uint8_t div){
	register uint16_t tmp;
	
	// check if within voltage range
	#if (MCLK_DIV_MINIMUM_RESTRICT == 0)
		if(div > 5){
			return(RES_PARAMERR);
		}
	#else
		if((div < MCLK_DIV_MINIMUM_RESTRICT)||(div > 5)){
			return(RES_PARAMERR);
		}
	#endif
	
	
	tmp = UCSCTL5;
	tmp &= ~DIVM_7;
	tmp |= div;
	UCSCTL5 = tmp;

	return(RES_OK);
}

//--------------------------------------------------------------------------------------------------
void sysInitClocks(void){
	// Initializes Clock System for devices with UCS
	
	// Set VCore to minimum allowed
	#if(_MAX_SYS_FREQ < 8000000L)
		SetVCore(0);
	#elif(_MAX_SYS_FREQ < 12000000L)
		SetVCore(1);
	#elif(_MAX_SYS_FREQ < 20000000L)
		SetVCore(2);
	#else
		SetVCore(3);
	#endif

	// Start XT1
	#ifdef _USING_XT1
		#if (XT1_FREQ < 40000L)
			// LF Mode
			UCSCTL6_L = XT1DRIVE1_L + XT1DRIVE0_L + XT1_XCAP;
		#else
			// HF Mode
			UCSCTL6_L = XT1DRIVE1_L + XT1DRIVE0_L + XTS;
		#endif
	#endif
	
	// Start XT2
	#ifdef _USING_XT2
		UCSCTL6_H = XT2DRIVE1_H + XT2DRIVE0_H;
	#endif
	
	// Let crystals settle
	#ifdef _USING_XT1
		#if (XT1_FREQ < 40000L)
			// LFXT
			while(UCSCTL7 & XT1LFOFFG){ // loop until XT1LF fault clears
				UCSCTL7 &= ~(DCOFFG+XT1LFOFFG+XT1HFOFFG+XT2OFFG);// Clear OSC fault Flags fault flags
				SFRIFG1 &= ~OFIFG;        // Clear OFIFG fault flag
			}
			UCSCTL6_L &= ~(XT1DRIVE1_L + XT1DRIVE0_L);
		#else
			//XT1 HF
			while(UCSCTL7 & XT1HFOFFG){ // loop until XT1HF fault clears
				UCSCTL7 &= ~(DCOFFG+XT1LFOFFG+XT1HFOFFG+XT2OFFG); // Clear OSC fault Flags
				SFRIFG1 &= ~OFIFG;        // Clear OFIFG fault flag
			}
			
			#if (XT1_FREQ < 8000000L)
				UCSCTL6 &= ~((~XT1DRIVE_0) & (XT1DRIVE_3));
			#elif (XT1_FREQ < 16000000L)
				UCSCTL6 &= ~((~XT1DRIVE_1) & (XT1DRIVE_3));
			#elif (XT1_FREQ < 24000000L)
				UCSCTL6 &= ~((~XT1DRIVE_2) & (XT1DRIVE_3));
			#endif
		#endif
	#endif
	
	#ifdef _USING_XT2
		while(UCSCTL7 & XT2OFFG){ // loop until XT2 fault clears
			UCSCTL7 &= ~(DCOFFG+XT1LFOFFG+XT1HFOFFG+XT2OFFG); // Clear OSC fault Flags
			SFRIFG1 &= ~OFIFG;								// Clear OFIFG fault flag
		}
		#if (XT2_FREQ < 8000000L)
			UCSCTL6 &= ~((~XT2DRIVE_0) & (XT2DRIVE_3));
		#elif (XT2_FREQ < 16000000L)
			UCSCTL6 &= ~((~XT2DRIVE_1) & (XT2DRIVE_3));
		#elif (XT2_FREQ < 24000000L)
			UCSCTL6 &= ~((~XT2DRIVE_2) & (XT2DRIVE_3));
		#endif
	#endif
	
	
	// Setup DCO
	#ifdef _USING_DCO
		#if(MANUALLY_CONFIG_DCO == 0)
			#error "Auto-DCO code not written yet"
		#else
			UCSCTL3 = FLL_SELREF + FLL_FLLREFDIV;
			
			UCSCTL0 = 0x0000;	// Set DCO to lowest Tap
			UCSCTL2 = (FLL_FLLD << 12) + FLL_FLLN;
			
			#if (DCO_FREQ <= 630000L)
				UCSCTL1 = DCORSEL_0;
			#elif (DCO_FREQ < 1250000L)
				UCSCTL1 = DCORSEL_1;
			#elif (DCO_FREQ < 2500000L)
				UCSCTL1 = DCORSEL_2;
			#elif (DCO_FREQ < 5000000L)
				UCSCTL1 = DCORSEL_3;
			#elif (DCO_FREQ < 10000000L)
				UCSCTL1 = DCORSEL_4;
			#elif (DCO_FREQ < 20000000L)
				UCSCTL1 = DCORSEL_5;
			#elif (DCO_FREQ < 40000000L)
				UCSCTL1 = DCORSEL_6;
			#else
				UCSCTL1 = DCORSEL_7;
			#endif
			
			
			while(UCSCTL7 & DCOFFG){ // loop until DCO fault clears
				UCSCTL7 &= ~(DCOFFG+XT1LFOFFG+XT1HFOFFG+XT2OFFG); // Clear OSC fault Flags
				SFRIFG1 &= ~OFIFG;								// Clear OFIFG fault flag
			}
		#endif
	#endif
	
	// Setup subsystem clock division
	UCSCTL5 = (ACLK_DIV << 8) + (SMCLK_DIV << 4) + DIVM__16;
	
	// Clock Routing
	UCSCTL4 = _SELA + _SELS + _SELM;
	
	// Set MCLK startup value
	UCSCTL5 = (ACLK_DIV << 8) + (SMCLK_DIV << 4) + MCLK_DIV;
}
#endif

//##################################################################################################

