/*
* Copyright (c) 2012, Alexander I. Mykyta
* All rights reserved.
* 
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met: 
* 
* 1. Redistributions of source code must retain the above copyright notice, this
*    list of conditions and the following disclaimer. 
* 2. Redistributions in binary form must reproduce the above copyright notice,
*    this list of conditions and the following disclaimer in the documentation
*    and/or other materials provided with the distribution. 
* 
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
* ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

/**
* \addtogroup MOD_DMA_STREAM DMA Stream
* \brief DMA I/O Streams
* \author Alex Mykyta (amykyta3@gmail.com)
* \details Implements streaming data in or out of a circular buffer using DMA
* \todo Test this module
* \attention This module has not been tested yet! I am committing it anyways just so you have it.
*
* \{
**/
 
/**
* \file
* \brief Include file for \ref MOD_DMA_STREAM "DMA Stream"
* \author Alex Mykyta (amykyta3@gmail.com)
**/

#ifndef __DMA_STREAM_H__
#define __DMA_STREAM_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <stddef.h>
#include <msp430_xc.h>

#include <stdint.h>
#include <stddef.h>
#include <msp430_xc.h>
#include "dma_isr.h"
#include "dma_internal.h"

//==================================================================================================
// Definitions
//==================================================================================================
typedef struct{
	uint8_t *bufptr;	// pointer to the buffer array
	size_t bufsize;		// size of buffer
	volatile int8_t laplead;// Amount of buffer laps the write head is leading (Ideally only 0 or 1)
	size_t rdidx;		// Points to the next address to be read
	DMA_CHANNEL_t *DMA; // DMA Channel Pointer
}DMA_INSTREAM_t;

typedef volatile struct{
	uint8_t *bufptr;	// pointer to the buffer array
	size_t bufsize;		// size of buffer
	volatile int8_t laplead;// Amount of buffer laps the write head is leading (Ideally only 0 or 1)
	size_t wridx;		// Points to the next address to be written
	DMA_CHANNEL_t *DMA; // DMA Channel Pointer
}DMA_OUTSTREAM_t;

//==================================================================================================
// Function Prototypes
//==================================================================================================
///\addtogroup DMASTREAM_FUNCTIONS Functions
///\{

/**
* \name DMA In-stream Functions
* \brief Implements input DMA stream buffering
* \details Data is copied from a register every time a DMA trigger occurs into a circular buffer.
* Once copied, this data can be read back out as the buffer is continuously filled. If data is 
* written to the buffer faster than it can be read, a buffer overrun occurs. This is only detectable
* after it occurs during a read operation. The erronous read operation automatically resets the
* circular buffer.
* \{
**/


void dma_instream_init(DMA_INSTREAM_t *dma_instream, void *bufptr, size_t bufsize,
						uint8_t dma_channel, uint8_t trigger, void *srcAddr, uint8_t wordsize);

RES_t dma_instream_read(DMA_INSTREAM_t *dma_instream, void *dst, size_t size);
RES_t dma_instream_peek(DMA_INSTREAM_t *dma_instream, void *dst, size_t size);
size_t dma_instream_rdcount(DMA_INSTREAM_t *dma_instream, RES_t *error); // Returns the maximum number of bytes that can be read from the stream

///\}

//--------------------------------------------------------------------------------------------------
/**
* \name DMA Out-stream Functions
* \brief Implements input DMA stream buffering
* \details Data is copied from from the end of a circular buffer to a register every time a DMA 
* trigger occurs.
* 
* - Somehow detect buffer underruns...?
* - Probably needs a pause function since starting an outstream will immediately underrun. Need to be
* 	able to preload the buffer.
* - How does one stop an outstream DMA?
* 
* \todo Functions not implemented yet.
* \{
**/

void dma_outstream_init(DMA_OUTSTREAM_t *dma_outstream, void *bufptr, size_t bufsize,
						uint8_t dma_channel, uint8_t trigger, void *dstAddr, uint8_t wordsize);

RES_t dma_outstream_write(DMA_OUTSTREAM_t *dma_outstream, void *src, size_t size);
size_t dma_outstream_wrcount(DMA_OUTSTREAM_t *dma_outstream); // Returns the maximum number of bytes that can be written to the stream
///\}
///\}

#ifdef __cplusplus
}
#endif

#endif

///\}
