#ifndef _COMMANDER_COMMANDS_H
#define _COMMANDER_COMMANDS_H

#include <commander.h>
#include <stdint.h>

// maximum length of a command input line (256 max)
#define MAX_CMDINBUF	64

// Maximum number of arguments in a command (including command). Set to 0 to disable argument splitting
#define CMD_MAX_ARGV	5

// Table of commands: {"command_word" , function_name }
#define CMDTABLE	{"hi"	,	cmdHello	},\
					{"args"	,	cmdArgList	}

// Custom command function prototypes:
CMDRES_t cmdHello(uint8_t argc, char *argv[], uint8_t reset);
CMDRES_t cmdArgList(uint8_t argc, char *argv[], uint8_t reset);


#endif
