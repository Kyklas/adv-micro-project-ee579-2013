/*
* Copyright (c) 2012, Alexander I. Mykyta
* All rights reserved.
* 
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met: 
* 
* 1. Redistributions of source code must retain the above copyright notice, this
*    list of conditions and the following disclaimer. 
* 2. Redistributions in binary form must reproduce the above copyright notice,
*    this list of conditions and the following disclaimer in the documentation
*    and/or other materials provided with the distribution. 
* 
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
* ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

/**
* \addtogroup MOD_CLOCKSYS
* \{
**/

/**
* \file
* \brief Internal include for \ref MOD_CLOCKSYS "Clock System".
* \author Alex Mykyta (amykyta3@gmail.com)
**/

///\}

#ifndef CLOCK_SYS_INTERNAL_H_
#define CLOCK_SYS_INTERNAL_H_

//##################################################################################################
//# Basic Clock Module                                                                             #
//# 1xx Devices                                                                                    #
//##################################################################################################
#ifdef __MSP430_HAS_BASIC_CLOCK__
	#error "Clock System not implemented yet"
#endif
//##################################################################################################
//# Basic Clock Module+                                                                            #
//# 2xx Devices                                                                                    #
//##################################################################################################
#ifdef __MSP430_HAS_BC2__
	#error "Clock System not implemented yet"
#endif
//##################################################################################################
//# Unified Clock System (UCS)                                                                     #
//# 5xx and 6xx Devices                                                                            #
//##################################################################################################
#ifdef __MSP430_HAS_UCS__

#if (XT1_FREQ != 0)
	#define _HAS_XT1
#endif

#if (XT2_FREQ != 0)
	#define _HAS_XT2
#endif

#if ((ACLK_SRC == 0)||(SMCLK_SRC == 0)||(MCLK_SRC == 0))
	#define _USING_DCO
#endif

#if ((ACLK_SRC == 1)||(SMCLK_SRC == 1)||(MCLK_SRC == 1))
	#ifdef _HAS_XT1
		#define _USING_XT1
	#else
		#error "XT1 Is not available!"
	#endif
#endif

#if ((ACLK_SRC == 2)||(SMCLK_SRC == 2)||(MCLK_SRC == 2))
	#ifdef _HAS_XT2
		#define _USING_XT2
	#else
		#error "XT2 Is not available!"
	#endif
#endif

//--------------------------------------------------------------------------------------------------
// UCS DCO & FLL Setup:
//
// Resulting Definitions:
//	FLL_SELREF
//	FLL_RATIO
//	DCO_FREQ
//	
#ifdef _USING_DCO
	#if(MANUALLY_CONFIG_DCO == 0)
		// Use the clocks available to automatically configure the FLL
		// Try to get as close as possible to the TARGET_DCO_FREQ
		// Favor using XT1 or XT2. REFO is a last resort.
		
		#if (TARGET_DCO_FREQ < ((32768L)*2))
			#error "TARGET_DCO_FREQ is too low"
		#endif
		
		//+++++ Add preproc-code for Auto Config of FLL
		
		
		
	#else //(MANUALLY_CONFIG_DCO != 0)
		
		
		#define FLL_FLLD		MANUAL_FLLD
		#define FLL_FLLN		MANUAL_FLLN
		
		#if(MANUAL_FLL_REF_SRC == 0)
			// XT1
			#ifdef _HAS_XT1
				#define FLL_SELREF	SELREF__XT1CLK
				#define _USING_XT1
				#define FLL_REF_FREQ	XT1_FREQ
			#else
				#error "Invalid MANUAL_FLL_REF_SRC"
			#endif
		#elif(MANUAL_FLL_REF_SRC == 1)
			// XT2
			#ifdef _HAS_XT2
				#define FLL_SELREF	SELREF__XT2CLK
				#define _USING_XT2
				#define FLL_REF_FREQ	XT2_FREQ
			#else
				#error "Invalid MANUAL_FLL_REF_SRC"
			#endif
		#elif(MANUAL_FLL_REF_SRC == 2)
			// REFO
			#define FLL_SELREF	SELREF__REFOCLK
			#define FLL_REF_FREQ	(32768L)
		#else
			#error "Invalid MANUAL_FLL_REF_SRC"
		#endif
		
		#if (MANUAL_FLLREFDIV == 0)
			#define DCO_FREQ		(FLL_REF_FREQ * (FLL_FLLN+1) * (1 << FLL_FLLD))
			#define FLL_FLLREFDIV	FLLREFDIV__1
		#elif (MANUAL_FLLREFDIV == 1)
			#define DCO_FREQ		((FLL_REF_FREQ * (FLL_FLLN+1) * (1 << FLL_FLLD))/2)
			#define FLL_FLLREFDIV	FLLREFDIV__2
		#elif (MANUAL_FLLREFDIV == 2)
			#define DCO_FREQ		((FLL_REF_FREQ * (FLL_FLLN+1) * (1 << FLL_FLLD))/4)
			#define FLL_FLLREFDIV	FLLREFDIV__4
		#elif (MANUAL_FLLREFDIV == 3)
			#define DCO_FREQ		((FLL_REF_FREQ * (FLL_FLLN+1) * (1 << FLL_FLLD))/8)
			#define FLL_FLLREFDIV	FLLREFDIV__8
		#elif (MANUAL_FLLREFDIV == 4)
			#define DCO_FREQ		((FLL_REF_FREQ * (FLL_FLLN+1) * (1 << FLL_FLLD))/12)
			#define FLL_FLLREFDIV	FLLREFDIV__12
		#elif (MANUAL_FLLREFDIV == 5)
			#define DCO_FREQ		((FLL_REF_FREQ * (FLL_FLLN+1) * (1 << FLL_FLLD))/16)
			#define FLL_FLLREFDIV	FLLREFDIV__16
		#else
			#error "Invalid MANUAL_FLLREFDIV"
		#endif
		
	#endif
#endif

//--------------------------------------------------------------------------------------------------

// ACLK
#if (ACLK_SRC == 0)
	#define		_ACLK_FREQ		(DCO_FREQ >> ACLK_DIV)
	#define		_SELA			SELA__DCOCLK
#elif (ACLK_SRC == 1)
	#define		_ACLK_FREQ		(XT1_FREQ >> ACLK_DIV)
	#define		_SELA			SELA__XT1CLK
#elif (ACLK_SRC == 2)
	#define		_ACLK_FREQ		(XT2_FREQ >> ACLK_DIV)
	#define		_SELA			SELA__XT2CLK
#elif (ACLK_SRC == 3)
	#define		_ACLK_FREQ		((10000L) >> ACLK_DIV)
	#define		_SELA			SELA__VLOCLK
#elif (ACLK_SRC == 4)
	#define		_ACLK_FREQ		((32768L) >> ACLK_DIV)
	#define		_SELA			SELA__REFOCLK
#else
	#error "Invalid ACLK_SRC"
#endif

// SMCLK
#if (SMCLK_SRC == 0)
	#define		_SMCLK_FREQ		(DCO_FREQ >> SMCLK_DIV)
	#define		_SELS			SELS__DCOCLK
#elif (SMCLK_SRC == 1)
	#define		_SMCLK_FREQ		(XT1_FREQ >> SMCLK_DIV)
	#define		_SELS			SELS__XT1CLK
#elif (SMCLK_SRC == 2)
	#define		_SMCLK_FREQ		(XT2_FREQ >> SMCLK_DIV)
	#define		_SELS			SELS__XT2CLK
#elif (SMCLK_SRC == 3)
	#define		_SMCLK_FREQ		((10000L) >> SMCLK_DIV)
	#define		_SELS			SELS__VLOCLK
#elif (SMCLK_SRC == 4)
	#define		_SMCLK_FREQ		((32768L) >> SMCLK_DIV)
	#define		_SELS			SELS__REFOCLK
#else
	#error "Invalid SMCLK_SRC"
#endif

// MCLK
#if (MCLK_SRC == 0)
	#define		_MCLK_BASE_FREQ	DCO_FREQ
	#define		_MCLK_FREQ		(DCO_FREQ >> (UCSCTL5 & 0x07))
	#define		_SELM			SELM__DCOCLK
#elif (MCLK_SRC == 1)
	#define		_MCLK_BASE_FREQ	XT1_FREQ
	#define		_MCLK_FREQ		(XT1_FREQ >> (UCSCTL5 & 0x07))
	#define		_SELM			SELM__XT1CLK
#elif (MCLK_SRC == 2)
	#define		_MCLK_BASE_FREQ	XT2_FREQ
	#define		_MCLK_FREQ		(XT2_FREQ >> (UCSCTL5 & 0x07))
	#define		_SELM			SELM__XT2CLK
#elif (MCLK_SRC == 3)
	#define		_MCLK_BASE_FREQ	(10000L)
	#define		_MCLK_FREQ		((10000L) >> (UCSCTL5 & 0x07))
	#define		_SELM			SELM__VLOCLK
#elif (MCLK_SRC == 4)
	#define		_MCLK_BASE_FREQ	(32768L)
	#define		_MCLK_FREQ		((32768L) >> (UCSCTL5 & 0x07))
	#define		_SELM			SELM__REFOCLK
#else
	#error "Invalid MCLK_SRC"
#endif

// XCAP calculation
#ifdef _USING_XT1
	#if (XT1_FREQ < 40000L)
		#define LFXT_REQUIRED_CAP	(20*LFXT_LOAD_CAP) // Includes pin cap. Ignores any trace cap.
								  // ^^ Multiplied by 10 to include tenths digit in calculation
		// Typical 5xx and 6xx caps available:
		//	XCAP_0 = 2.0
		//	XCAP_1 = 5.5
		//	XCAP_2 = 8.5
		//	XCAP_3 = 12.0
		
		// Midpoints derived from above:
		//	3.75
		//	7
		//	10.25
		
		#if (LFXT_REQUIRED_CAP <= 37)
			#define XT1_XCAP	XCAP_0
		#elif (LFXT_REQUIRED_CAP <= 70)
			#define XT1_XCAP	XCAP_1
		#elif (LFXT_REQUIRED_CAP <= 102)
			#define XT1_XCAP	XCAP_2
		#else
			#define XT1_XCAP	XCAP_3
		#endif
		
	#endif
#endif

// Maximum system frequency
#if ((_ACLK_FREQ > _SMCLK_FREQ) && (_ACLK_FREQ > _MCLK_BASE_FREQ))
	// ACLK is highest
	#define _MAX_SYS_FREQ	_ACLK_FREQ
#elif ((_SMCLK_FREQ > _ACLK_FREQ) && (_SMCLK_FREQ > _MCLK_BASE_FREQ))
	// SMCLK is highest
	#define _MAX_SYS_FREQ	_SMCLK_FREQ
#else
	// MCLK can be highest
	#define _MAX_SYS_FREQ	_MCLK_BASE_FREQ
#endif

// cleanup
#ifndef XT1HFOFFG
	#define XT1HFOFFG	0x0000
#endif

#ifndef XT2OFFG
	#define XT2OFFG	0x0000
#endif

#define		_MCLK_MAXLEVEL	5

//--------------------------------------------------------------------------------------------------
#endif

//##################################################################################################
#endif
