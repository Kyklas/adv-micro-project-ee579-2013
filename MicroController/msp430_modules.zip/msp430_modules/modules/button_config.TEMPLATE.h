/**
* \addtogroup MOD_BUTTON
* \{
**/

/**
* \file
* \brief Configuration include file for \ref MOD_BUTTON "Pushbutton Events"
* \author Alex Mykyta (amykyta3@gmail.com)
**/

#ifndef _BUTTON_CONFIG_H_
#define _BUTTON_CONFIG_H_

//==================================================================================================
// Pushbutton Events Config
//
// Configuration for: PROJECT_NAME
//==================================================================================================


/** \addtogroup DEF_BUTTON_CONFIG Configuration Defines
*	\brief Configuration defines for the Pushbutton Events module
*
* The pushbutton events module uses the MSP430's hardware timer. Since it only uses Capture-Control
* registers 1 and 2, it can share the same hardware timer device with the following other modules:
*	- \ref MOD_SEQUENCER "Output Sequencer" (Only uses Capture-Control register 0)
*
*	To ensure proper operation when sharing the timer, All of the timer settings must be identical.
*	Other signals using the same IO port cannot use interrupts outside of this module.
* \{ **/

/// \brief Enable/disable button events on Port1
#define BUTTON_PORT1		1	///< \hideinitializer
/**<	0 = Disable	\n
*		1 = Enable
**/

/// \brief Enable/disable button events on Port2
#define BUTTON_PORT2		1	///< \hideinitializer
/**<	0 = Disable	\n
*		1 = Enable
**/

/// \brief Select which Timer module to use
#define BUTTON_USE_DEV		0	///< \hideinitializer
/**<	0 = Timer A0 \n
* 		1 = Timer A1 \n
* 		2 = Timer A2
**/

/// \brief Select which timer clock source to use
#define BUTTON_CLK_SRC		1	///< \hideinitializer
/**<	1 = ACLK	\n
*		2 = SMCLK
**/

/// \brief Select which clock division to use
#define BUTTON_IDIV		3	///< \hideinitializer
/**<	0 = /1 \n
*		1 = /2 \n
*		2 = /4 \n
*		3 = /8 \n
**/

/// \brief Select which extended clock division to use
#define BUTTON_IDIVEX		0	///< \hideinitializer
/**<	0 = /1 \n
*		1 = /2 \n
*		2 = /3 \n
*		3 = /4 \n
*		4 = /5 \n
*		5 = /6 \n
*		6 = /7 \n
*		7 = /8 \n
**/

/// \brief Debounce delay time in milliseconds.
#define BUTTON_DEBOUNCETIME		50	///< \hideinitializer

/// \brief Time in milliseconds until onButtonHold() event is triggered
#define BUTTON_HOLDTIME			1500	///< \hideinitializer

///\}
	
#endif /*_BUTTON_CONFIG_H_*/
///\}
